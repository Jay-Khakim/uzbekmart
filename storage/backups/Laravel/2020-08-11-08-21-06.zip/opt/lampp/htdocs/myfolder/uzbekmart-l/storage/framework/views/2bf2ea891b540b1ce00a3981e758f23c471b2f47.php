<?php $__env->startSection('content'); ?>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-primary">
        <div class="card-body pb-0">
            <div class="btn-group float-right">
                <button class="btn btn-transparent dropdown-toggle p-0" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-bookmark-o" aria-hidden="true"></i></button>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div>
            </div>
            <div class="text-value"> <h1>290</h1>  </div>
            <div> 
                <h2>Conpanies</h2>
            </div>
        </div>
        <div class="chart-wrapper mt-3 mx-3" style="height:70px;">
            <div class="chartjs-size-monitor">
                <div class="chartjs-size-monitor-expand">
                    <div class="">
                    </div>
                </div>
                    <div class="chartjs-size-monitor-shrink">
                        <div class="">
                        </div>
                    </div>
                </div>
        <canvas class="chart chartjs-render-monitor" id="card-chart1" height="70" style="display: block; width: 127px; height: 70px;" width="127"></canvas>
        <div id="card-chart1-tooltip" class="chartjs-tooltip bottom" style="opacity: 0; left: 72.5371px; top: 147.396px;">
            <div class="tooltip-header"><div class="tooltip-header-item">July</div>
        </div>
        <div class="tooltip-body">
            <div class="tooltip-body-item"><span class="tooltip-body-item-color" style="background-color: rgba(255, 255, 255, 0.55);"></span>
                <span class="tooltip-body-item-label">My First dataset</span>
                <span class="tooltip-body-item-value">40</span>
            </div>
        </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(backpack_view('blank'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/vendor/backpack/crud/src/resources/views/base/dashboard.blade.php ENDPATH**/ ?>