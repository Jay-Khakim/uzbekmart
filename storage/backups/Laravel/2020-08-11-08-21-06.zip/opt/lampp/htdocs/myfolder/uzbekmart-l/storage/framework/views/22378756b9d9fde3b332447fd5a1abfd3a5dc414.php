<!-- This file is used to store sidebar items, starting with Backpack\Base 0.9.0 -->
<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('dashboard')); ?>"><i class="la la-home nav-icon"></i> <?php echo e(trans('backpack::base.dashboard')); ?></a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('blog')); ?>'><i class='nav-icon la la-question'></i> Blogs</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('buyrequest')); ?>'><i class='nav-icon la la-question'></i> Buyrequests</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('category')); ?>'><i class='nav-icon la la-question'></i> Categories</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('company')); ?>'><i class='nav-icon la la-question'></i> Companies</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('investment')); ?>'><i class='nav-icon la la-question'></i> Investments</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('product')); ?>'><i class='nav-icon la la-question'></i> Products</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('service')); ?>'><i class='nav-icon la la-question'></i> Services</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('subcategory')); ?>'><i class='nav-icon la la-question'></i> Subcategories</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('tag')); ?>'><i class='nav-icon la la-question'></i> Tags</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('banners')); ?>'><i class='nav-icon la la-question'></i> Banners</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('log')); ?>'><i class='nav-icon la la-terminal'></i> Logs</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('backup')); ?>'><i class='nav-icon la la-hdd-o'></i> Backups</a></li><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/vendor/backpack/base/inc/sidebar_content.blade.php ENDPATH**/ ?>