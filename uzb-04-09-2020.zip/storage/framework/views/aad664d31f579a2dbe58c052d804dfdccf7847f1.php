<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('about-us', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('about-us', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('about-us', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('about-us', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('about-us', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    <a href="<?php echo e(route('about-us', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="breadcrumb-content">
            <h2><?php echo app('translator')->get("About Us"); ?></h2>
            <ul>
                <li><a href="<?php echo e(route('main' ,app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                <li class="active"><?php echo app('translator')->get("About Us"); ?></li>
            </ul>
        </div>
    </div>
</div>

  <!-- Begin Hiraola's About Us Area -->
        <div class="about-us-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-7 d-flex align-items-center">
                        <div class="overview-content">
                            <h2 align="center"><?php echo app('translator')->get("Welcome To <span>Uzbekmart.com</span>"); ?></h2>
                            <p class="short_desc"><?php echo app('translator')->get("UzbekMart online showroom is a project launched to provide Uzbekistan's export products to foreign partners and promote large-scale export of Uzbekistan's national products abroad. The project was launched by the Association of exporters of Uzbekistan, which aims to provide national products with education in various areas of our country. The main goal of the project is to create an e-Commerce system on the territory of the Republic of Uzbekistan, as well as to replenish funds for the formation of the digital economy system and increase the export potential of the Republic of Uzbekistan."); ?></p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-5">
                        <div class="overview-img text-center img-hover_effect">
                            <a href="#">
                                <img class="img-full" src="../../assets/images/about-us/1.jpg" alt="Hiraola's About Us Image">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's About Us Area End Here -->

        
        <?php echo $__env->make('inc.statistics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/about.blade.php ENDPATH**/ ?>