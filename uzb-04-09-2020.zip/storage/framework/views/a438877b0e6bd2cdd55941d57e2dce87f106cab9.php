<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('single-request', ['language' => 'uz', 'id' => $buyrequest->id]), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('single-request', ['language' => 'en', 'id' => $buyrequest->id]), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('single-request', ['language' => 'ru', 'id' => $buyrequest->id]), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('single-request', ['language' => 'uz', 'id' => $buyrequest->id]), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('single-request', ['language' => 'ru', 'id' => $buyrequest->id]), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    <a href="<?php echo e(route('single-request', ['language' => 'en', 'id' => $buyrequest->id]), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <!-- Begin Hiraola's Breadcrumb Area -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2><?php echo app('translator')->get("Buy or Request"); ?></h2>
                <ul>
                    <li><a href="<?php echo e(route("main", app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li class="active"><?php echo app('translator')->get("Services"); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Hiraola's Breadcrumb Area End Here -->

    <!-- Begin Hiraola's Single Product Area -->
    <div class="sp-area">
        <div class="container">
            <div class="sp-nav">
                <div class="row">
                    <div class="col-lg-5 col-md-5">
                        <div class="sp-img_area">
                            <div class="zoompro-border">
                                <img class="zoompro" src="/storage/<?php echo e($buyrequest->image, false); ?>" alt=" <?php echo e($buyrequest->name, false); ?> " />
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-7">
                        <div class="sp-content">
                            <div class="sp-heading">
                                <h5><a href="#"><?php echo e($buyrequest->name, false); ?></a></h5>
                            </div>
                            
                            <span class="reference"><?php echo app('translator')->get("Published at"); ?>:  <?php echo e($buyrequest->created_at, false); ?> </span> 
                            
                            
                            <div class="sp-essential_stuff mt-4">
                                <ul>
                                    <li><?php echo app('translator')->get("Customer"); ?>: <?php echo e($buyrequest->company, false); ?> </li>
                                    <li><?php echo app('translator')->get("Address"); ?>: <?php echo e($buyrequest->address, false); ?></li>
                                    <li><?php echo app('translator')->get("Phone"); ?>: +<?php echo e($buyrequest->phone, false); ?></li>
                                    <li><?php echo app('translator')->get("How much"); ?>:<span><?php echo e($buyrequest->amount, false); ?></span></a></li>
                                    
                                    <li><?php echo app('translator')->get("Category"); ?>: <a href="javascript:void(0)"><?php echo e($buyrequest->category->name, false); ?></a></li>
                                    <li><?php echo app('translator')->get("More"); ?>:  <?php echo $buyrequest->wants; ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <br>
                <br>
            </div>
        </div>
    </div>
    <!-- Hiraola's Single Product Area End Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/buy-request/single-request.blade.php ENDPATH**/ ?>