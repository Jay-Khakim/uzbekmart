<?php $__env->startSection('language'); ?>
     <li>
        <a href="<?php echo e(route('check-company', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('check-company', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('check-company', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('check-company', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('check-company', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    <a href="<?php echo e(route('check-company', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Hiraola's Content Wrapper Area -->
        <div class="hiraola-content_wrapper" style="margin-bottom: 100px;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div style="border: 2px double #1288B0; background-color: white; padding: 10px;">
                          <table border="0" cellspacing="2" cellpadding="2" style="margin: 0px auto; width: 50%;">
                            <tbody>
                                <tr><td style="text-align: left; font-weight: bold;"><?php echo app('translator')->get("Enter <br/> STIR code"); ?></td>
                                    <td style="padding-right: 10px;">
                                        <input type="text" id="OKPO" name="OKPO" style="float: right; width: 170px;" /> 
                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td style="padding-right: 15px; display: inline; float: right;"><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        <button style="border: medium none; padding: 0px; margin: 0px; width: 170px; float: right; background: none 0% 0% repeat scroll transparent;" onclick="refresh();return false;">
                                            <img width="170" id="cimage" src="http://registr.stat.uz/ext/c/index.php?PHPSESSID=ijmq4pkkah40nsuk4f7uuj9u51" />
                                        </button> 
                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td style="font-size: 11px; text-align: right;"><?php echo app('translator')->get("To change the picture refresh the site"); ?>
                                    </td>
                                </tr>

                              <tr>
                                    <td style="font-weight: bold;"> <?php echo app('translator')->get("Write code <br/> in the picture"); ?>
                                    </td>
                                    <td style="padding-right: 10px;">
                                        <input type="text" id="keystring" name="keystring" style="float: right; width: 170px;" /> 
                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <br>
                                    <td style=" text-align: right;"> 
                                        <button name="per" class="btn  btn-primary"  style="width: 180px;">
                                            <?php echo app('translator')->get("Search"); ?>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Content Wrapper Area End Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/services/check-company.blade.php ENDPATH**/ ?>