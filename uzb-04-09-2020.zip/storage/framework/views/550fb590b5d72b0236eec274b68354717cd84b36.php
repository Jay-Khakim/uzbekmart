<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('comp-show', ['language' => 'uz', 'id' => $company->id]), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('comp-show', ['language' => 'en', 'id' => $company->id]), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('comp-show', ['language' => 'ru', 'id' => $company->id]), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('comp-show', ['language' => 'uz', 'id' => $company->id]), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('comp-show', ['language' => 'ru', 'id' => $company->id]), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    <a href="<?php echo e(route('comp-show', ['language' => 'en', 'id' => $company->id]), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Hiraola's Breadcrumb Area -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2><?php echo e($company->name, false); ?></h2>
                <ul>
                    <li><a href="<?php echo e(route('main' ,app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li class="active">
                            <?php if($company->companytype === 'local'): ?>
                                <?php echo app('translator')->get("Local company"); ?>
                            <?php else: ?> 
                                <?php echo app('translator')->get("Foreign company"); ?>
                            <?php endif; ?>
                        
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Hiraola's Breadcrumb Area End Here -->

    <!-- Begin Hiraola's Single Product Area -->
    <div class="sp-area">
        <div class="container">
            <div class="sp-nav">
                <div class="row">
                    <div class="col-lg-5 col-md-5">
                        <div class="sp-img_area">
                            <div class="zoompro-border">
                                <img  src="/storage/<?php echo e($company->image, false); ?>" alt=" <?php echo e($company->name, false); ?> " />
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-7">
                        <div class="sp-content">
                            <div class="sp-heading">
                                <h5><a href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$company->id]), false); ?>"><?php echo e($company->name, false); ?></a></h5>
                            </div>
                            <span class="reference">
                                <?php if($company->companytype === 'local'): ?>
                                    <?php echo app('translator')->get("Local company"); ?>
                                <?php else: ?> 
                                    <?php echo app('translator')->get("Foreign company"); ?>
                                <?php endif; ?>
                            </span>
                            <hr>
                            <div class="sp-essential_stuff">
                                <ul>
                                    <h5><span class="badge  badge-primary">#<?php echo e($company->category->name, false); ?></span></h5>
                                    <br>
                                    <li><b><?php echo app('translator')->get("Phone"); ?>: </b> <span>&nbsp;&nbsp;<?php echo e($company->phone, false); ?></span></li>
                                    <br>
                                    <li><b><?php echo app('translator')->get("Website"); ?>: </b><span>&nbsp;&nbsp;
                                        <?php if($company->web): ?>
                                            <a href="<?php echo e($company->web, false); ?>"><?php echo e($company->web, false); ?></a>
                                        <?php else: ?> 
                                            <?php echo app('translator')->get("Not exist yet"); ?>
                                        <?php endif; ?>
                                    </span>
                                    </li>
                                    <br>
                                    <li><b><?php echo app('translator')->get("Email"); ?>: </b><a href="javascript:void(0)"><?php echo e($company->email, false); ?></a></li>
                                    <br>
                                    <li><b><?php echo app('translator')->get("Address"); ?></b>:  <?php echo e($company->address, false); ?></li>
                                    <br>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Hiraola's Single Product Area End Here -->

    <!-- Begin Hiraola's Single Product Tab Area -->
    <div class="hiraola-product-tab_area-2 sp-product-tab_area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sp-product-tab_nav ">
                        <div class="product-tab">
                            <ul class="nav product-menu">
                                <li><a class="active" data-toggle="tab" href="#description"><span><?php echo app('translator')->get("Description"); ?></span></a></li>
                            </ul>
                        </div>
                        <div class="tab-content hiraola-tab_content">
                            <div id="description" class="tab-pane active show" role="tabpanel">
                                <div class="product-description">
                                    <ul>
                                        <li>
                                            <strong><?php echo e($company->name, false); ?></strong>
                                            <span><?php echo $company->desc; ?></span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Hiraola's Single Product Tab Area End Here -->

    <!-- Begin Hiraola's Product Area Two -->
    <div class="hiraola-product_area hiraola-product_area-2 section-space_add">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hiraola-section_title">
                        <h4><?php echo app('translator')->get("Company Products"); ?></h4>
                    </div>
                </div>

                <div class="col-lg-12">
                    <div class="hiraola-product_slider-3">
                        <?php if(count($products)>0): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Begin Hiraola's Slide Item Area -->
                                <div class="slide-item">
                                    <div class="single_product">
                                        <div class="product-img">
                                            <a href="<?php echo e(route('product-show', ['language'=>app()->getLocale(), 'id'=>$company->id, 'pid'=>$product->id]), false); ?>">
                                                <img class="primary-img" src="/storage/<?php echo e($product->image, false); ?> " alt="<?php echo e($product->name, false); ?>">
                                            </a>
                                            
                                        </div>
                                        <div class="hiraola-product_content">
                                            <div class="product-desc_info">
                                                <br>
                                                <h6 align="center"><a class="product-name" href="<?php echo e(route('product-show', ['language'=>app()->getLocale(), 'id'=>$company->id, 'pid'=>$product->id]), false); ?>"><?php echo e($product->name, false); ?></a></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Hiraola's Slide Item Area End Here -->

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo app('translator')->get("Not found"); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Hiraola's Product Area Two End Here -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/companies/comp-show.blade.php ENDPATH**/ ?>