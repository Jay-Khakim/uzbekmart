<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('services', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('services', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('services', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('services', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('services', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    <a href="<?php echo e(route('services', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Hiraola's Breadcrumb Area -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2><?php echo app('translator')->get("Services"); ?></h2>
                <ul>
                    <li><a href="<?php echo e(route('main' ,app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li class="active"><?php echo app('translator')->get("Services"); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Hiraola's Breadcrumb Area End Here -->


      <!-- Begin Hiraola's Content Wrapper Area -->
        <div class="hiraola-content_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 order-2 order-lg-2">
                        <div class="hiraola-sidebar-catagories_area">

                            

                            
                        </div>
                    </div>
                    <div class="col-lg-12 order-1 order-lg-1">
                        <div class="shop-toolbar">
                            <div class="product-view-mode">
                                <a class="grid-3" data-target="gridview-3" data-toggle="tooltip" data-placement="top" title="Grid View"><i class="fa fa-th"></i></a>
                                <a class="active list" data-target="listview" data-toggle="tooltip" data-placement="top" title="List View"><i class="fa fa-th-list"></i></a>
                            </div>
                            <span><?php echo app('translator')->get('Totally'); ?>: 
                                <?php echo e(count($services), false); ?>

                                <?php if(count($services)>1): ?>
                                    <?php echo app('translator')->get('services'); ?>
                                <?php else: ?> 
                                    <?php echo app('translator')->get('service'); ?>
                                <?php endif; ?>

                            </span>
                            
                        </div>
                        <div class="shop-product-wrap grid listview row">
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="slide-item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('service-show', [app()->getLocale(), $service->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($service->image, false); ?>" alt=" <?php echo e($service->name, false); ?> ">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6 align="center"><?php echo app('translator')->get("Company"); ?>: <a class="product-name" href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$service->company->id]), false); ?>"> <?php echo e($service->company->name, false); ?> </a></h6>
                                                    <h6 align="center"><?php echo app('translator')->get("Service"); ?>: <a class="product-name" href="<?php echo e(route('service-show', [app()->getLocale(), $service->id]), false); ?>"> <?php echo e($service->name, false); ?> </a></h6>
                                                    <div class="additional-add_action">
                                                        <ul>
                                                            <li class="quick-view-btn" data-toggle="modal" data-target="#exampleModalCenter"><a href="javascript:void(0)" data-toggle="tooltip" data-placement="top" title="Quick View"><i
                                                                class="ion-eye"></i></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('service-show', [app()->getLocale(), $service->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($service->image, false); ?>" alt="<?php echo e($service->name, false); ?>">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6><?php echo app('translator')->get("Company"); ?>:  <a class="product-name" href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$service->company->id]), false); ?>"><?php echo e($service->company->name, false); ?></a></h6>
                                                    <h6><?php echo app('translator')->get("Service"); ?>: <a class="product-name" href="<?php echo e(route('service-show', [app()->getLocale(), $service->id]), false); ?>"> <?php echo e($service->name, false); ?> </a></h6>
                                                    <div class="product-short_desc">
                                                        <p> <?php echo $service->desc; ?> </p>
                                                    </div>
                                                </div>
                                                <div class="add-actions">
                                                    <ul>
                                                        <li><a class="hiraola-add_cart" href="<?php echo e(route('service-show', [app()->getLocale(), $service->id]), false); ?>" data-toggle="tooltip" data-placement="top" title="Batafsil Information"><?php echo app('translator')->get("More"); ?></a></li>
                                                        
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Content Wrapper Area End Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/services/services.blade.php ENDPATH**/ ?>