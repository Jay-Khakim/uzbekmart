    <div class="container">
        <div class="row">
            <div class="col-sm-6"> 
                <?php
                $widgets['after_content'][] = [
                    'type'       => 'chart',
                    'controller' => \App\Http\Controllers\Admin\Charts\WeeklyNewCompaniesChartController::class,
            
                    // OPTIONALS
            
                    // 'class'   => 'card mb-2',
                    // 'wrapper' => ['class'=> 'col-md-6'] ,
                    'content' => [
                        'header' => 'New Companies', 
                        'body'   => 'This chart should make it obvious how many new Companies have signed up in the past 7 days.<br><br>',
                    ],
                ];
                // $widgets['after_content'][] = [
                //     'type'       => 'chart',
                //     'controller' => \App\Http\Controllers\Admin\Charts\PieChartProductsChartController::class,
            
                //     // OPTIONALS
            
                //     // 'class'   => 'card mb-2',
                //     // 'wrapper' => ['class'=> 'col-md-6'] ,
                //     'content' => [
                //         'header' => 'New Companies', 
                //         'body'   => 'This chart should make it obvious how many new Companies have signed up in the past 7 days.<br><br>',
                //     ],
                // ];
                ?>

            </div>
        
            </div>
    </div>
   

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-sm-6 col-lg-3">
                <div class="card text-white bg-gray-800">
                  <div class="card-body">
                    <div class="text-value"><?php echo e(App\Models\Company::count(), false); ?></div>
                    <div>All Companies</div>
                    <div class="progress progress-white progress-xs my-2">
                      <div class="progress-bar" role="progressbar" style="width: <?php echo e(App\Models\Company::count(), false); ?>%" aria-valuemin="0" aria-valuemax="1000"></div>
                    </div>
                    <small class="text-muted"><?php echo e(App\Models\Company::count(), false); ?> out of 1000</small>
                  </div>
                </div>
              </div>

        <div class="col-sm-6 col-lg-3">
                <div class="card text-white bg-info">
                  <div class="card-body">
                    <div class="text-value"><?php echo e(App\Models\Category::count(), false); ?></div>
                    <div>Categories</div>
                    <div class="progress progress-white progress-xs my-2">
                      <div class="progress-bar" role="progressbar" style="width: <?php echo e(App\Models\Category::count(), false); ?>%"  aria-valuemin="0" aria-valuemax="100"></div>
                    </div><small class="text-muted"><?php echo e(App\Models\Category::count(), false); ?> out of 100</small>
                  </div>
                </div>
              </div>

        <div class="col-sm-6 col-lg-3">
                <div class="card text-white bg-primary">
                  <div class="card-body">
                    <div class="text-value"><?php echo e(App\Models\Subcategory::count(), false); ?></div>
                    <div>Subcategories</div>
                    <div class="progress progress-white progress-xs my-2">
                      <div class="progress-bar" role="progressbar" style="width: <?php echo e(App\Models\Subcategory::count(), false); ?>%" aria-valuemin="0" aria-valuemax="100"></div>
                    </div><small class="text-muted"><?php echo e(App\Models\Subcategory::count(), false); ?> out of 100</small>
                  </div>
                </div>
              </div>      
        
        <div class="col-sm-6 col-lg-3">
                <div class="card text-white bg-warning">
                  <div class="card-body">
                    <div class="text-value"><?php echo e(App\Models\Subscribe::count(), false); ?></div>
                    <div>Subscribers</div>
                    <div class="progress progress-white progress-xs my-2">
                      <div class="progress-bar" role="progressbar" style="width: <?php echo e(App\Models\Subscribe::count(), false); ?>%" aria-valuemin="0" aria-valuemax="1000"></div>
                    </div><small class="text-muted"><?php echo e(App\Models\Subscribe::count(), false); ?> out of 1000</small>
                  </div>
                </div>
              </div>
        <div class="col-sm-6 col-md-2">
                <div class="card text-white bg-dark">
                  <div class="card-body">
                    <div class="h1 text-muted text-right mb-4"><i class="la la-building"></i></div>
                    <div class="text-value"><?php echo e(App\Models\Company::where('companytype', 'foreign')->count(), false); ?></div><small class="text-muted text-uppercase font-weight-bold">Foreign Companies</small>
                    <div class="progress progress-white progress-xs mt-3">
                        <div class="progress-bar" role="progressbar" style="width: <?php echo e(App\Models\Company::where('companytype', 'foreign')->count(), false); ?>%" ria-valuemin="0" aria-valuemax="1000"></div>
                    </div>
                    <small class="text-muted"><?php echo e(App\Models\Company::where('companytype', 'foreign')->count(), false); ?> out of 1000</small>
                  </div>
                </div>
              </div>

        <div class="col-sm-6 col-md-2">
                <div class="card text-white bg-dark">
                  <div class="card-body">
                    <div class="h1 text-muted text-right mb-4"><i class="la la-building"></i></div>
                    <div class="text-value"><?php echo e(App\Models\Company::where('companytype', 'local')->count(), false); ?></div><small class="text-muted text-uppercase font-weight-bold">Local Companies</small>
                    <div class="progress progress-white progress-xs mt-3">
                        <div class="progress-bar" role="progressbar" style="width: <?php echo e(App\Models\Company::where('companytype', 'local')->count(), false); ?>%" ria-valuemin="0" aria-valuemax="1000"></div>
                    </div>
                    <small class="text-muted"><?php echo e(App\Models\Company::where('companytype', 'local')->count(), false); ?> out of 1000</small>
                  </div>
                </div>
              </div>
        
        <div class="col-sm-6 col-md-2">
                <div class="card text-white bg-warning">
                  <div class="card-body">
                    <div class="h1 text-muted text-right mb-4"><i class="la la-product-hunt"></i></div>
                    <div class="text-value"><?php echo e(App\Models\Product::count(), false); ?></div><small class="text-muted text-uppercase font-weight-bold">Products</small>
                    <div class="progress progress-white progress-xs mt-3">
                      <div class="progress-bar" role="progressbar" style="width: <?php echo e(App\Models\Product::count(), false); ?>%"  aria-valuemin="0" aria-valuemax="1000"></div>
                    </div>
                    <small class="text-muted"><?php echo e(App\Models\Product::count(), false); ?> out of 1000</small>
                  </div>
                </div>
              </div>

        <div class="col-sm-6 col-md-2">
                <div class="card text-white bg-success">
                  <div class="card-body">
                    <div class="h1 text-muted text-right mb-4"><i class="la la-user"></i></div>
                    <div class="text-value"><?php echo e(App\Models\Service::count(), false); ?></div><small class="text-muted text-uppercase font-weight-bold">Services</small>
                    <div class="progress progress-white progress-xs mt-3">
                      <div class="progress-bar" role="progressbar" style="width: <?php echo e(App\Models\Service::count(), false); ?>%"  aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <small class="text-muted"><?php echo e(App\Models\Service::count(), false); ?> out of 100</small>
                  </div>
                </div>
              </div>
        
        <div class="col-sm-6 col-md-2">
                <div class="card text-white bg-primary">
                  <div class="card-body">
                    <div class="h1 text-muted text-right mb-4"><i class="la la-blog"></i></div>
                    <div class="text-value"><?php echo e(App\Models\Blog::count(), false); ?></div><small class="text-muted text-uppercase font-weight-bold">Blogs</small>
                    <div class="progress progress-white progress-xs mt-3">
                      <div class="progress-bar" role="progressbar" style="width: <?php echo e(App\Models\Blog::count(), false); ?>%"  aria-valuemin="0" aria-valuemax="1000"></div>
                    </div>
                    <small class="text-muted"><?php echo e(App\Models\Blog::count(), false); ?> out of 1000</small>
                  </div>
                </div>
              </div>

        <div class="col-sm-6 col-md-2">
          <div class="card text-white bg-danger">
            <div class="card-body">
              <div class="h1 text-muted text-right mb-4"><i class="la la-money"></i></div>
              <div class="text-value"><?php echo e(App\Models\Investment::count(), false); ?></div><small class="text-muted text-uppercase font-weight-bold">Investments</small>
              <div class="progress progress-white progress-xs mt-3">
                <div class="progress-bar" role="progressbar" style="width: <?php echo e(App\Models\Investment::count(), false); ?>%"  aria-valuemin="0" aria-valuemax="500"></div>
              </div>
              <small class="text-muted"><?php echo e(App\Models\Investment::count(), false); ?> out of 500</small>
            </div>
          </div>
        </div>
        
        
       
        
        
    
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make(backpack_view('blank'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/vendor/backpack/crud/src/resources/views/base/dashboard.blade.php ENDPATH**/ ?>