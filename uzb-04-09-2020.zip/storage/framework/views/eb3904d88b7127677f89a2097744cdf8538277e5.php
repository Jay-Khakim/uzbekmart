<!-- text input -->

<?php

// the field should work whether or not Laravel attribute casting is used
if (isset($field['value']) && (is_array($field['value']) || is_object($field['value']))) {
    $field['value'] = json_encode($field['value']);
}

?>

<?php echo $__env->make('crud::fields.inc.wrapper_start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <label><?php echo $field['label']; ?></label>
    <?php echo $__env->make('crud::fields.inc.translatable_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input type="hidden"
           value="<?php echo e(old($field['name']) ? old($field['name']) : (isset($field['value']) ? $field['value'] : (isset($field['default']) ? $field['default'] : '' )), false); ?>"
           name="<?php echo e($field['name'], false); ?>">

    <?php if(isset($field['prefix']) || isset($field['suffix'])): ?>
        <div class="input-group"> <?php endif; ?>
            <?php if(isset($field['prefix'])): ?>
                <div class="input-group-addon"><?php echo $field['prefix']; ?></div> <?php endif; ?>
            <?php if(isset($field['store_as_json']) && $field['store_as_json']): ?>
                <input
                        type="text"
                        data-google-address="{&quot;field&quot;: &quot;<?php echo e($field['name'], false); ?>&quot;, &quot;full&quot;: <?php echo e(isset($field['store_as_json']) && $field['store_as_json'] ? 'true' : 'false', false); ?> }"
                        data-init-function="bpFieldInitAddressGoogleElement"
                        <?php echo $__env->make('crud::fields.inc.attributes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                >
            <?php else: ?>
                <input
                        type="text"
                        data-google-address="{&quot;field&quot;: &quot;<?php echo e($field['name'], false); ?>&quot;, &quot;full&quot;: <?php echo e(isset($field['store_as_json']) && $field['store_as_json'] ? 'true' : 'false', false); ?> }"
                        data-init-function="bpFieldInitAddressGoogleElement"
                        name="<?php echo e($field['name'], false); ?>"
                        value="<?php echo e(old($field['name']) ? old($field['name']) : (isset($field['value']) ? $field['value'] : (isset($field['default']) ? $field['default'] : '' )), false); ?>"
                        <?php echo $__env->make('crud::fields.inc.attributes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                >
            <?php endif; ?>
            <?php if(isset($field['suffix'])): ?>
                <div class="input-group-addon"><?php echo $field['suffix']; ?></div> <?php endif; ?>
            <?php if(isset($field['prefix']) || isset($field['suffix'])): ?> </div> <?php endif; ?>

    
    <?php if(isset($field['hint'])): ?>
        <p class="help-block"><?php echo $field['hint']; ?></p>
    <?php endif; ?>
<?php echo $__env->make('crud::fields.inc.wrapper_end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>






<?php if($crud->fieldTypeNotLoaded($field)): ?>
    <?php
        $crud->markFieldTypeAsLoaded($field);
    ?>

    
    <?php $__env->startPush('crud_fields_styles'); ?>
        <style>
            .ap-input-icon.ap-icon-pin {
                right: 5px !important;
            }

            .ap-input-icon.ap-icon-clear {
                right: 10px !important;
            }
        </style>
    <?php $__env->stopPush(); ?>

    
    <?php $__env->startPush('crud_fields_scripts'); ?>
        <script>

            function bpFieldInitAddressGoogleElement(element) {
                var $addressConfig = element.data('google-address');
                var $field = $('[name="' + $addressConfig.field + '"]');

                if ($field.val().length) {
                    var existingData = JSON.parse($field.val());
                    element.val(existingData.value);
                }

                var $autocomplete = new google.maps.places.Autocomplete(
                    (element[0]),
                    {types: ['geocode']});

                $autocomplete.addListener('place_changed', function fillInAddress() {

                    var place = $autocomplete.getPlace();
                    var value = element.val();
                    var latlng = place.geometry.location;
                    var data = {"value": value, "latlng": latlng};

                    for (var i = 0; i < place.address_components.length; i++) {
                        var addressType = place.address_components[i].types[0];
                        data[addressType] = place.address_components[i]['long_name'];
                    }
                    $field.val(JSON.stringify(data));

                });

                element.change(function(){
                    if (!element.val().length) {
                        $field.val("");
                    }
                });
            }

            //Function that will be called by Google Places Library
            function initGoogleAddressAutocomplete() {
                $('[data-google-address]').each(function () {
                    var element = $(this);
                    var functionName = element.data('init-function');

                    if (typeof window[functionName] === "function") {
                      window[functionName](element);
                    }
                });
            }

        </script>
        <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($field['api_key'] ?? config('services.google_places.key'), false); ?>&libraries=places&callback=initGoogleAddressAutocomplete" async defer></script>

    <?php $__env->stopPush(); ?>

<?php endif; ?>


<?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/vendor/backpack/crud/src/resources/views/crud/fields/address_google.blade.php ENDPATH**/ ?>