<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('investments', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('investments', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('investments', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('investments', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('investments', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    <a href="<?php echo e(route('investments', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Hiraola's Breadcrumb Area -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2><?php echo app('translator')->get("Investment projects"); ?></h2>
                <ul>
                    <li><a href="<?php echo e(route('main' ,app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li class="active"><?php echo app('translator')->get("Investment projects"); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Hiraola's Breadcrumb Area End Here -->


    <!-- Begin Hiraola's Content Wrapper Area -->
        <div class="hiraola-content_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 order-2 order-lg-1">
                        <div class="hiraola-sidebar-catagories_area">
                            <div class="hiraola-sidebar_categories">
                                <div class="hiraola-categories_title">
                                    <h5 align="center"><?php echo app('translator')->get("Amount of investments: "); ?></h5>
                                    <h5 align="center">$
                                        <?php
                                            $sum = 0;
                                            foreach($investments as $invest){
                                                $sum = $sum + $invest->amount;
                                            }
                                            echo $sum;
                                        ?> 
                                    </h5>
                                </div>
                            </div>
                            
                            <div class="category-module hiraola-sidebar_categories">
                                <div class="category-module_heading">
                                    <h5><?php echo app('translator')->get("Categories"); ?></h5>
                                </div>
                                <div class="module-body">
                                    <ul class="module-list_item">
                                        <li>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="javascript:void(0)"><?php echo e($category->name, false); ?> (
                                                    <?php echo e(count(\App\Models\Investment::where('category_id', $category->id)->get()), false); ?>

                                                )</a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="col-lg-9 order-1 order-lg-2">
                        <div class="shop-toolbar">
                            <div class="product-view-mode">
                                
                                <a class=" active list" data-target="listview" data-toggle="tooltip" data-placement="top" title="List View"><i class="fa fa-th-list"></i></a>
                            </div>
                            <span><?php echo app('translator')->get('Totally'); ?>: 
                                <?php echo e(count($investments), false); ?>

                                <?php if(count($investments)>1): ?>
                                    <?php echo app('translator')->get('investment projects'); ?>
                                <?php else: ?> 
                                    <?php echo app('translator')->get('investment project'); ?>
                                <?php endif; ?>

                            </span>
                             
                            
                        </div>
                        <div class="shop-product-wrap grid listview row">
                            
                            <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="javascript:void(0)">
                                                    <img class="primary-img" src="/assets/images/i/01.jpg" alt="<?php echo e($invest->title, false); ?>">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h4><a class="product-name" href="javascript:void(0)">“<?php echo e($invest->title, false); ?>"</a></h4>
                                                    
                                                    <div class="product-short_desc">
                                                        
                                                        <b><?php echo app('translator')->get("Address"); ?>: </b><?php echo e($invest->address, false); ?><br>
                                                        <b><?php echo app('translator')->get("Project name"); ?>:</b> <?php echo e($invest->title, false); ?> <br>
                                                        <b><?php echo app('translator')->get("Category"); ?>:</b> <?php echo e($invest->category->name, false); ?><br>
                                                        <b><?php echo app('translator')->get("Avarage power"); ?></b>: <?php echo e($invest->avaragepower, false); ?><br>
                                                        <b><?php echo app('translator')->get("Amount ($ mln)"); ?></b>: <?php echo e($invest->amount, false); ?> <br>
                                                        <b><?php echo app('translator')->get("IRR (fin), for 10 years (%)"); ?></b>: <?php echo e($invest->iir, false); ?> <br>
                                                        <b><?php echo app('translator')->get("NPV (fin), for 10 years (%)"); ?></b>: <?php echo e($invest->npv, false); ?> <br>
                                                        <b><?php echo app('translator')->get("Payback (months)"); ?></b>: <?php echo e($invest->payback, false); ?> <br>
                                                        <b><?php echo app('translator')->get("Work places"); ?></b>: <?php echo e($invest->workplaces, false); ?> <br>
                                                        <b><?php echo app('translator')->get("Phone"); ?></b>: +998 71 145 45 02 <br>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($investments->links(), false); ?>

                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Content Wrapper Area End Here -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
    <script>
        $(document).ready(function(){
            $("#findBtn").click(function(){
                var cat = $("#catID").val();
                var region = $('#region_select').val();
                $.ajax({
                type: 'get',
                dataType: 'html',
                url: '<?php echo e(route("investments", app()->getLocale() ), false); ?>',
                data: 'cat_id=' + cat + '&region=' + region,
                success:function(response){
                    console.log(response);
                    $("#productData").html(response);
                }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/investments/investments.blade.php ENDPATH**/ ?>