<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('local-comp', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('local-comp', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('local-comp', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('local-comp', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('local-comp', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    <a href="<?php echo e(route('local-comp', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2><?php echo app('translator')->get("Local companies"); ?></h2>
                <ul>
                    <li><a href="<?php echo e(route("main", app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li><?php echo app('translator')->get("Companies"); ?></a></li>
                    <li class="active"><?php echo app('translator')->get("Local companies"); ?></li>
                </ul>
            </div>
        </div>
    </div>


<!-- Begin Hiraola's Content Wrapper Area -->
        <div class="hiraola-content_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="shop-toolbar">
                            <div class="product-view-mode">
                                <a class=" grid-3" data-target="gridview-3" data-toggle="tooltip" data-placement="top" title="Grid View"><i class="fa fa-th"></i></a>
                                
                            </div>
                            <span><?php echo app('translator')->get('Totally'); ?>: 
                                <?php echo e(count($localcomp), false); ?>

                                <?php if(count($localcomp)>1): ?>
                                    <?php echo app('translator')->get('companies'); ?>
                                <?php else: ?> 
                                    <?php echo app('translator')->get('company'); ?>
                                <?php endif; ?>

                            </span>
                            
                        </div>
                        <div class="shop-product-wrap grid gridview-5 row">

                            
                            <?php $__currentLoopData = $localcomp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                
                                <div class="col-lg-4">
                                    <div class="slide-item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$local->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($local->image, false); ?>" alt="<?php echo e($local->name, false); ?>">
                                                </a>

                                                <span class="sticker-2">New</span>
                                            </div>
                                            <br>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h5><span class="badge  badge-primary"> #<?php echo e($local->category->name, false); ?> </span></h5>
                                                    <h6 align="center"><a class="product-name" href="<?php echo e(route('comp-show', [app()->getLocale(), $local->id]), false); ?>"> <?php echo e($local->name, false); ?> </a></h6>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('comp-show', [app()->getLocale(), $local->id]), false); ?>">
                                                    <img class="primary-img" src=" <?php echo e($local->image, false); ?>" alt="<?php echo e($local->name, false); ?> ">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6><a class="product-name" href="<?php echo e(route('comp-show', [app()->getLocale(), $local->id]), false); ?>"> <?php echo e($local->name, false); ?> </a></h6>
                                                    
                                                    <div class="product-short_desc">
                                                        <p><?php echo e($local->desc, false); ?></p>
                                                    </div>
                                                </div>
                                                <div class="add-actions">
                                                    <ul>
                                                        <li><a class="hiraola-add_cart" href="<?php echo e(route('comp-show', [app()->getLocale(), $local->id]), false); ?>" data-toggle="tooltip" data-placement="top" title="More info"><?php echo app('translator')->get("More"); ?></a></li>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            

                        </div>
                    <?php echo e($localcomp->links(), false); ?>


                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Content Wrapper Area End Here -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
    <script>
        $(document).ready(function () {
            $('.product_sorting_btn').click(function () {
                let orderBy = $(this).data('order')
                $('.sorting_text').text($(this).find('span').text())
                $.ajax({
                    url: "<?php echo e(route('local-comp' ,app()->getLocale()), false); ?>",
                    type: "GET",
                    data: {
                        orderBy: orderBy
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: (data) => {
                        let positionParameters = location.pathname.indexOf('?');
                        let url = location.pathname.substring(positionParameters,location.pathname.length);
                        let newURL = url + '?'; // http://127.0.0.1:8001/phones?
                        // console.log(newURL);
                        newURL += 'orderBy=' + orderBy; // http://127.0.0.1:8001/phones?orderBy=name-z-a
                        history.pushState({}, '', newURL);
                        $('.product_grid').html(data)
                        $('.product_grid').isotope('destroy')
                        $('.product_grid').imagesLoaded( function() {
                            let grid = $('.product_grid').isotope({
                                itemSelector: '.product',
                                layoutMode: 'fitRows',
                                fitRows:
                                    {
                                        gutter: 30
                                    }
                            });
                        });
                    }
                });
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/companies/local-comp.blade.php ENDPATH**/ ?>