<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('single-blog', ['language' => 'uz', 'id' => $blog->id]), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('single-blog', ['language' => 'en', 'id' => $blog->id]), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('single-blog', ['language' => 'ru', 'id' => $blog->id]), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('single-blog', ['language' => 'uz', 'id' => $blog->id]), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('single-blog', ['language' => 'ru', 'id' => $blog->id]), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    <a href="<?php echo e(route('single-blog', ['language' => 'en', 'id' => $blog->id]), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Hiraola's Breadcrumb Area -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2><?php echo e($blog->title, false); ?> </h2>
                <ul>
                    <li><a href="<?php echo e(route("main", app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li class="active"><?php echo app('translator')->get("Blog"); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Hiraola's Breadcrumb Area End Here -->

      <!-- Begin Hiraola's Blog Details Right Sidebar Area -->
        <div class="hiraola-blog_area hiraola-blog_area-2 hiraola-blog-details hiraola-banner_area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 order-lg-2 order-2">
                        <div class="hiraola-blog-sidebar-wrapper">
                            <div class="hiraola-blog-sidebar">
                                <div class="hiraola-sidebar-search-form">
                                    <form action="javascript:void(0)">
                                        <input type="text" class="hiraola-search-field" placeholder="search here">
                                        <button type="submit" class="hiraola-search-btn"><i class="fa fa-search"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9 order-lg-1 order-1">
                        <div class="blog-item">
                            <div class="blog-img img-hover_effect">
                                <a href="blog-details-left-sidebar.html">
                                    <img src="/storage/<?php echo e($blog->image, false); ?>" alt="<?php echo e($blog->title, false); ?>">
                                </a>
                                <div class="blog-meta-2">
                                    <div class="blog-time_schedule">
                                        <span class="day"><?php echo e($blog->created_at->format('Y-m-d'), false); ?></span>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="blog-content">
                                <div class="blog-heading" align="center">
                                    <h5>
                                        <a href="javascrip:void(0)"><?php echo e($blog->title, false); ?> </a>
                                    </h5>
                                </div>
                                
                            </div>
                            <div class="hiraola-blog-blockquote">
                                <blockquote>
                                    <p><?php echo $blog->body; ?>

                                    </p>
                                </blockquote>
                            </div>
                            
                            
                            <div class="hiraola-social_link">
                                <ul>
                                    <li class="facebook">
                                        <a href="https://www.facebook.com/uzbekmart" data-toggle="tooltip" target="_blank" title="Facebook">
                                            <i class="fab fa-facebook"></i>
                                        </a>
                                    </li>
                                    
                                    <li class="instagram">
                                        <a href="https://www.instagram.com/uzbekmart/" data-toggle="tooltip" target="_blank" title="Instagram">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div><br><br>
        <!-- Hiraola's Blog Details Right Sidebar Area End Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/blog/blog.blade.php ENDPATH**/ ?>