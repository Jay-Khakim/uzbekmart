
<li filter-name="<?php echo e($filter->name, false); ?>"
	filter-type="<?php echo e($filter->type, false); ?>"
	class="nav-item dropdown <?php echo e(Request::get($filter->name)?'active':'', false); ?>">
    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e($filter->label, false); ?> <span class="caret"></span></a>
    <div class="dropdown-menu p-0">

			<div class="form-group backpack-filter mb-0">
					<?php
                        $from = '';
                        $to = '';
                        if ($filter->currentValue) {
                            $range = (array) json_decode($filter->currentValue);
                            $from = $range['from'];
                            $to = $range['to'];
                        }
                    ?>
					<div class="input-group">
				        <input class="form-control pull-right from"
				        		type="number"
									<?php if($from): ?>
										value = "<?php echo e($from, false); ?>"
									<?php endif; ?>
									<?php if(array_key_exists('label_from', $filter->options)): ?>
										placeholder = "<?php echo e($filter->options['label_from'], false); ?>"
									<?php else: ?>
										placeholder = "min value"
									<?php endif; ?>
				        		>
								<input class="form-control pull-right to"
				        		type="number"
									<?php if($to): ?>
										value = "<?php echo e($to, false); ?>"
									<?php endif; ?>
									<?php if(array_key_exists('label_to', $filter->options)): ?>
										placeholder = "<?php echo e($filter->options['label_to'], false); ?>"
									<?php else: ?>
										placeholder = "max value"
									<?php endif; ?>
				        		>
				        <div class="input-group-append range-filter-<?php echo e($filter->name, false); ?>-clear-button">
				          <a class="input-group-text" href=""><i class="la la-times"></i></a>
				        </div>
				    </div>
			</div>
    </div>
  </li>








    








<?php $__env->startPush('crud_list_scripts'); ?>
	<script>
		jQuery(document).ready(function($) {
			$("li[filter-name=<?php echo e($filter->name, false); ?>] .from, li[filter-name=<?php echo e($filter->name, false); ?>] .to").change(function(e) {
				e.preventDefault();
				var from = $("li[filter-name=<?php echo e($filter->name, false); ?>] .from").val();
				var to = $("li[filter-name=<?php echo e($filter->name, false); ?>] .to").val();
				if (from || to) {
					var range = {
						'from': from,
						'to': to
					};
					var value = JSON.stringify(range);
				} else {
					//this change to empty string,because addOrUpdateUriParameter method just judgment string
					var value = '';
				}
				var parameter = '<?php echo e($filter->name, false); ?>';

				// behaviour for ajax table
				var ajax_table = $('#crudTable').DataTable();
				var current_url = ajax_table.ajax.url();
				var new_url = addOrUpdateUriParameter(current_url, parameter, value);

				// replace the datatables ajax url with new_url and reload it
				new_url = normalizeAmpersand(new_url.toString());
				ajax_table.ajax.url(new_url).load();

				// add filter to URL
				crud.updateUrl(new_url);

				// mark this filter as active in the navbar-filters
				if (URI(new_url).hasQuery('<?php echo e($filter->name, false); ?>', true)) {
					$('li[filter-name=<?php echo e($filter->name, false); ?>]').removeClass('active').addClass('active');
				}
			});

			$('li[filter-name=<?php echo e($filter->name, false); ?>]').on('filter:clear', function(e) {
				$('li[filter-name=<?php echo e($filter->name, false); ?>]').removeClass('active');
				$("li[filter-name=<?php echo e($filter->name, false); ?>] .from").val("");
				$("li[filter-name=<?php echo e($filter->name, false); ?>] .to").val("");
				$("li[filter-name=<?php echo e($filter->name, false); ?>] .to").trigger('change');
			});

			// range clear button
			$(".range-filter-<?php echo e($filter->name, false); ?>-clear-button").click(function(e) {
				e.preventDefault();

				$('li[filter-name=<?php echo e($filter->name, false); ?>]').trigger('filter:clear');
			})

		});
	</script>
<?php $__env->stopPush(); ?>



<?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/vendor/backpack/crud/src/resources/views/crud/filters/range.blade.php ENDPATH**/ ?>