<?php
    $value = data_get($entry, $column['name']);
    $column['prefix'] = $column['prefix'] ?? '';
    $column['escaped'] = $column['escaped'] ?? true;
    $column['wrapper']['element'] = $column['wrapper']['element'] ?? 'a';
    $column['wrapper']['target'] = $column['wrapper']['target'] ?? '_blank';
?>

<span>
    <?php if($value && count($value)): ?>
        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file_path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $column['wrapper']['href'] = $column['wrapper']['href'] ?? ( isset($column['disk'])?asset(\Storage::disk($column['disk'])->url($file_path)):asset($column['prefix'].$file_path) );
            $text = $column['prefix'].$file_path;
        ?>
            <?php echo $__env->renderWhen(!empty($column['wrapper']), 'crud::columns.inc.wrapper_start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <?php if($column['escaped']): ?>
                - <?php echo e($text, false); ?> <br/>
            <?php else: ?>
                - <?php echo $text; ?> <br/>
            <?php endif; ?>
        <?php echo $__env->renderWhen(!empty($column['wrapper']), 'crud::columns.inc.wrapper_end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        -
    <?php endif; ?>
</span>
<?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/vendor/backpack/crud/src/resources/views/crud/columns/upload_multiple.blade.php ENDPATH**/ ?>