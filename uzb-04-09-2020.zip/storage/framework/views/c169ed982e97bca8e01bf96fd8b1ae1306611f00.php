<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('foreign-comp', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('foreign-comp', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('foreign-comp', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('foreign-comp', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('foreign-comp', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    <a href="<?php echo e(route('foreign-comp', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2><?php echo app('translator')->get("Foreign companies"); ?></h2>
                <ul>
                    <li><a href="<?php echo e(route("main", app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li><?php echo app('translator')->get("Companies"); ?></a></li>
                    <li class="active"><?php echo app('translator')->get("Foreign companies"); ?></li>
                </ul>
            </div>
        </div>
    </div>


<!-- Begin Hiraola's Content Wrapper Area -->
        <div class="hiraola-content_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="shop-toolbar">
                            <div class="product-view-mode">
                                <a class=" grid-3" data-target="gridview-3" data-toggle="tooltip" data-placement="top" title="Grid View"><i class="fa fa-th"></i></a>
                                
                            </div>
                            <span><?php echo app('translator')->get('Totally'); ?>: 
                                <?php echo e(count($foreigncomp), false); ?>

                                <?php if(count($foreigncomp)>1): ?>
                                    <?php echo app('translator')->get('companies'); ?>
                                <?php else: ?> 
                                    <?php echo app('translator')->get('company'); ?>
                                <?php endif; ?>

                            </span>
                            
                        </div>
                        <div class="shop-product-wrap grid gridview-5 row">

                            
                            <?php $__currentLoopData = $foreigncomp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foreign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="slide-item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                
                                                <a href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$foreign->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($foreign->image, false); ?>" alt="<?php echo e($foreign->name, false); ?>">
                                                </a>

                                                <span class="sticker-2">New</span>
                                            </div>
                                            <br>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h5><span class="badge  badge-primary"> #<?php echo e($foreign->category->name, false); ?> </span></h5>
                                                    <h6 align="center"><a class="product-name" href="<?php echo e(route('comp-show', [app()->getLocale(), $foreign->id]), false); ?>"> <?php echo e($foreign->name, false); ?> </a></h6>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('comp-show', [app()->getLocale(), $foreign->id]), false); ?>">
                                                    <img class="primary-img" src=" <?php echo e($foreign->image, false); ?>" alt="<?php echo e($foreign->name, false); ?> ">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6><a class="product-name" href="<?php echo e(route('comp-show', [app()->getLocale(), $foreign->id]), false); ?>"> <?php echo e($foreign->name, false); ?> </a></h6>
                                                    
                                                    <div class="product-short_desc">
                                                        <p><?php echo e($foreign->desc, false); ?></p>
                                                    </div>
                                                </div>
                                                <div class="add-actions">
                                                    <ul>
                                                        <li><a class="hiraola-add_cart" href="../company/local/l31.html" data-toggle="tooltip" data-placement="top" title="More info"><?php echo app('translator')->get("More"); ?></a></li>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            

                            
                        </div>
                        <?php echo e($foreigncomp->links(), false); ?>

                        
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Content Wrapper Area End Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/companies/foreign-comp.blade.php ENDPATH**/ ?>