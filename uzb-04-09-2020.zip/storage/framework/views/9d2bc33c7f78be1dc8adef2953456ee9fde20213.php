<?php $__env->startSection('language'); ?>
     <li>
        <a href="<?php echo e(route('service-show', ['language' => 'uz', 'id' => $service_id]), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('service-show', ['language' => 'en', 'id' => $service_id]), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('service-show', ['language' => 'ru', 'id' => $service_id]), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('service-show', ['language' => 'uz', 'id' => $service_id]), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('service-show', ['language' => 'ru', 'id' => $service_id]), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    <a href="<?php echo e(route('service-show', ['language' => 'en', 'id' => $service_id]), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Hiraola's Breadcrumb Area -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2><?php echo e($service->name, false); ?></h2>
                <ul>
                    <li><a href="<?php echo e(route('main' ,app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li class="active"><?php echo app('translator')->get("Services"); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Hiraola's Breadcrumb Area End Here -->

    <!-- Begin Hiraola's Single Product Area -->
    <div class="sp-area">
        <div class="container">
            <div class="sp-nav">
                <div class="row">
                    <div class="col-lg-5 col-md-5">
                        <div class="sp-img_area">
                            <div class="zoompro-border">
                                <img  src="/storage/<?php echo e($service->image, false); ?>" data-zoom-image="/storage/<?php echo e($service->image, false); ?>" alt="<?php echo e($service->name, false); ?>" />
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-7">
                        <div class="sp-content">
                            <div class="sp-heading">
                                <h5><a href="#"> <?php echo e($service->name, false); ?> </a></h5>
                            </div>
                            <span class="reference"><?php echo app('translator')->get("Service type"); ?>: <strong><?php echo e($service->service, false); ?></strong></span>
                            <br>
                            <br>
                            <span class="reference"><?php echo app('translator')->get("Company"); ?>: <a href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$service->company->id]), false); ?>"> <strong> <?php echo e($service->company->name, false); ?></strong></a></span>
                            <div class="sp-essential_stuff">
                                <ul>
                                    <li><b><?php echo app('translator')->get("Phone"); ?>: </b><span><?php echo e($service->phone, false); ?></span></li>
                                    <br>
                                    <br>
                                    <li><b><?php echo app('translator')->get("Website"); ?>: </b><a href="<?php echo e($service->web, false); ?>"><?php echo e($service->web, false); ?></a></li>
                                    <br>
                                    <br>
                                    <li><b><?php echo app('translator')->get("Email"); ?>: </b><a href="javascript:void(0)"><?php echo e($service->email, false); ?></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Hiraola's Single Product Area End Here -->

    <!-- Begin Hiraola's Single Product Tab Area -->
        <div class="hiraola-product-tab_area-2 sp-product-tab_area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="sp-product-tab_nav ">
                            <div class="product-tab">
                                <ul class="nav product-menu">
                                    <li><a class="active" data-toggle="tab" href="#description"><span><?php echo app('translator')->get("Description"); ?></span></a></li>
                                </ul>
                            </div>
                            <div class="tab-content hiraola-tab_content">
                                <div id="description" class="tab-pane active show" role="tabpanel">
                                    <div class="product-description">
                                        <ul>
                                            <li>
                                                <strong><?php echo app('translator')->get("About Service"); ?></strong>
                                                <span> <?php echo e($service->desc, false); ?> </span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><br><br>
        <!-- Hiraola's Single Product Tab Area End Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/services/service-show.blade.php ENDPATH**/ ?>