<?php
    $value = is_string($entry->{$column['name']}) ? 
                json_decode($entry->{$column['name']}, true) : 
                $entry->{$column['name']};
    $column['text'] = json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    $column['escaped'] = $column['escaped'] ?? true;
    $column['wrapper']['element'] = $column['wrapper']['element'] ?? 'pre';
?>

<?php echo $__env->renderWhen(!empty($column['wrapper']), 'crud::columns.inc.wrapper_start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
    <?php if($column['escaped']): ?>
        <?php echo e($column['text'], false); ?>

    <?php else: ?>
        <?php echo $column['text']; ?>

    <?php endif; ?>
<?php echo $__env->renderWhen(!empty($column['wrapper']), 'crud::columns.inc.wrapper_end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
<?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/vendor/backpack/crud/src/resources/views/crud/columns/json.blade.php ENDPATH**/ ?>