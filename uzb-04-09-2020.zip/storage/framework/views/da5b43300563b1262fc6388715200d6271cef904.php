<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('blogs', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('blogs', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('blogs', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('blogs', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('blogs', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    <a href="<?php echo e(route('blogs', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Hiraola's Breadcrumb Area -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2><?php echo app('translator')->get("Blog"); ?> </h2>
                <ul>
                    <li><a href="<?php echo e(route("main", app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li class="active"><?php echo app('translator')->get("Blog"); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Hiraola's Breadcrumb Area End Here -->

      <!-- Begin Hiraola's Blog Column Three Area -->
        <div class="hiraola-blog_area hiraola-blog_area-2 grid-view_area blog-column-three_area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row blog-item_wrap">

                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-lg-4">
                                    <div class="blog-item">
                                        <div class="blog-img img-hover_effect">
                                            <a href="<?php echo e(route('single-blog', ['language'=>app()->getLocale(), 'id'=>$blog->id]), false); ?>">
                                                <img src="/storage/<?php echo e($blog->image, false); ?>" alt="Hiraola's Blog Image">
                                            </a>
                                            <div class="blog-meta-2">
                                                <div class="blog-time_schedule">
                                                    <span class="day"> <?php echo e($blog->created_at->format('Y-m-d'), false); ?> </span>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <div class="blog-content">
                                            <div class="blog-heading">
                                                <h5>
                                                    <a href="<?php echo e(route('single-blog', ['language'=>app()->getLocale(), 'id'=>$blog->id]), false); ?>"><?php echo e($blog->title, false); ?></a>
                                                </h5>
                                            </div>
                                            <div class="blog-short_desc">
                                                <p>
                                                    <?php
                                                        if(strlen($blog->body)> 150){
                                                            echo substr($blog->body, 0, 150)."...";
                                                        }else {
                                                            echo $blog->body;
                                                        }  
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="hiraola-read-more_area">
                                                <a href="<?php echo e(route('single-blog', ['language'=>app()->getLocale(), 'id'=>$blog->id]), false); ?>" class="hiraola-read_more"><?php echo app('translator')->get("More"); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Blog Column Three Area End Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/blog/blogs.blade.php ENDPATH**/ ?>