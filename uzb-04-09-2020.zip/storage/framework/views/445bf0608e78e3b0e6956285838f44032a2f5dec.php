<?php $__env->startSection('language'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Hiraola's Breadcrumb Area -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2> '<?php echo e($_GET['query'], false); ?>'</h2>
                <ul>
                    <li><a href="<?php echo e(route("main", app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li class="active"><?php echo app('translator')->get("Search"); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Hiraola's Breadcrumb Area End Here -->
    

    <!-- Begin Hiraola's Content Wrapper Area -->
    <div class="hiraola-content_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 order-2 order-lg-2 mt-4">
                    <div class="hiraola-sidebar-catagories_area">

                        <div class="category-module hiraola-sidebar_categories">
                            <div class="category-module_heading">
                                <h5><?php echo app('translator')->get("Sections"); ?></h5>
                            </div>
                            <div class="module-body">
                                <ul class="module-list_item">
                                    <li>
                                        <a href="javascript:void(0)"><?php echo app('translator')->get("Companies"); ?> <span class="badge badge-pill badge-info"> <?php echo e(count($companies), false); ?> </span></a>
                                        <a href="javascript:void(0)"><?php echo app('translator')->get("Products"); ?> <span class="badge badge-pill badge-info"><?php echo e(count($products), false); ?></span></a>
                                        <a href="javascript:void(0)"><?php echo app('translator')->get("Blog"); ?> <span class="badge badge-pill badge-info"><?php echo e(count($blogs), false); ?></span></a>
                                        <a href="javascript:void(0)"><?php echo app('translator')->get("Services"); ?> <span class="badge badge-pill badge-info"><?php echo e(count($services), false); ?></span></a>
                                        <a href="javascript:void(0)"><?php echo app('translator')->get("Investments"); ?> <span class="badge badge-pill badge-info"><?php echo e(count($investments), false); ?></span></a>
                                        <a href="javascript:void(0)"><?php echo app('translator')->get("Buy/Requests"); ?> <span class="badge badge-pill badge-info"><?php echo e(count($buyrequests), false); ?></span></a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>
                    <div class="sidebar-banner_area">
                        <div class="banner-item img-hover_effect">
                            <a href="javascript:void(0)">
                                <img src="/assets/images/banner/1_1.jpg" alt="Hiraola's Shop Banner Image">
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 order-1 order-lg-1">
                    <div class="shop-product-wrap grid listview row">
                        <h3><?php echo app('translator')->get("Search results"); ?>:  <?php echo e(count($companies)+count($buyrequests)+count($products)+count($services)+count($investments)+count($blogs), false); ?></h3>
                        <?php if(count($companies)>0): ?>
                        
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class="col-lg-4">
                                    <div class="slide-item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$company->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($company->image, false); ?>" alt="<?php echo e($company->name, false); ?>">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6 align="center"><a class="product-name" href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$company->id]), false); ?>"><?php echo e($company->name, false); ?></a></h6>
                                                    <div class="additional-add_action">
                                                        <ul>
                                                            <li class="quick-view-btn" data-toggle="modal" data-target="#exampleModalCenter"><a href="javascript:void(0)" data-toggle="tooltip" data-placement="top" title="Quick View"><i
                                                                class="ion-eye"></i></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$company->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($company->image, false); ?>" alt="<?php echo e($company->name, false); ?>">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6><a class="product-name" href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$company->id]), false); ?>"><?php echo e($company->name, false); ?></a></h6>
                                                    <div class="product-short_desc">
                                                        <p>
                                                            <?php
                                                                if(strlen($company->desc)> 150){
                                                                    echo substr($company->desc, 0, 150)."...";
                                                                }else {
                                                                    echo $company->desc;
                                                                } 
                                                            ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="add-actions">
                                                    <ul>
                                                        <li><a class="hiraola-add_cart" href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$company->id]), false); ?>" data-toggle="tooltip" data-placement="top" title="Batafsil Information"><?php echo app('translator')->get("More"); ?></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?> 

                        <?php if(count($products)>0): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="slide-item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('product-show', ['language'=>app()->getLocale(), 'id'=>$product->company->id, 'pid'=>$product->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($product->image, false); ?>" alt="<?php echo e($product->name, false); ?>">
                                                </a>
                                                
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6 align="center"><a class="product-name" href="<?php echo e(route('product-show', ['language'=>app()->getLocale(), 'id'=>$product->company->id, 'pid'=>$product->id]), false); ?>"><?php echo e($product->name, false); ?></a></h6>
                                                    <div class="additional-add_action">
                                                        <ul>
                                                            <li class="quick-view-btn" data-toggle="modal" data-target="#exampleModalCenter"><a href="javascript:void(0)" data-toggle="tooltip" data-placement="top" title="Quick View"><i
                                                                class="ion-eye"></i></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('product-show', ['language'=>app()->getLocale(), 'id'=>$product->company->id, 'pid'=>$product->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($product->image, false); ?>" alt="Hiraola's Product Image">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6><a class="product-name" href="<?php echo e(route('product-show', ['language'=>app()->getLocale(), 'id'=>$product->company->id, 'pid'=>$product->id]), false); ?>"><?php echo e($product->name, false); ?></a></h6>
                                                    <div class="product-short_desc">
                                                        <p>
                                                            <?php
                                                            if(strlen($product->desc)> 150){
                                                                echo substr($product->desc, 0, 150)."...";
                                                            }else {
                                                                echo $product->desc;
                                                            } 
                                                        ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="add-actions">
                                                    <ul>
                                                        <li><a class="hiraola-add_cart" href="<?php echo e(route('product-show', ['language'=>app()->getLocale(), 'id'=>$product->company->id, 'pid'=>$product->id]), false); ?>" data-toggle="tooltip" data-placement="top" title="Batafsil Information"><?php echo app('translator')->get("More"); ?></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        <?php endif; ?>


                        <?php if(count($services)>0): ?>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="slide-item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('service-show', [app()->getLocale(), $service->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($service->image, false); ?>" alt="<?php echo e($service->service, false); ?>">
                                                </a>
                                                
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6 align="center"><a class="product-name" href="<?php echo e(route('service-show', [app()->getLocale(), $service->id]), false); ?>"><?php echo e($service->service, false); ?></a></h6>
                                                    <div class="additional-add_action">
                                                        <ul>
                                                            <li class="quick-view-btn" data-toggle="modal" data-target="#exampleModalCenter"><a href="javascript:void(0)" data-toggle="tooltip" data-placement="top" title="Quick View"><i
                                                                class="ion-eye"></i></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('service-show', [app()->getLocale(), $service->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($service->image, false); ?>" alt="<?php echo e($service->service, false); ?>">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6><a class="product-name" href="<?php echo e(route('service-show', [app()->getLocale(), $service->id]), false); ?>"><?php echo e($service->service, false); ?></a></h6>
                                                    <div class="product-short_desc">
                                                        <p>
                                                            <?php
                                                            if(strlen($service->desc)> 150){
                                                                echo substr($service->desc, 0, 150)."...";
                                                            }else {
                                                                echo $service->desc;
                                                            } 
                                                        ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="add-actions">
                                                    <ul>
                                                        <li><a class="hiraola-add_cart" href="<?php echo e(route('service-show', [app()->getLocale(), $service->id]), false); ?>" data-toggle="tooltip" data-placement="top" title="Batafsil Information"><?php echo app('translator')->get("More"); ?></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <?php if(count($blogs)>0): ?>
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="slide-item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('single-blog', ['language'=>app()->getLocale(), 'id'=>$blog->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($blog->image, false); ?>" alt="<?php echo e($blog->title, false); ?>">
                                                </a>
                                                
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6 align="center"><a class="product-name" href="<?php echo e(route('single-blog', ['language'=>app()->getLocale(), 'id'=>$blog->id]), false); ?>"><?php echo e($blog->title, false); ?></a></h6>
                                                    <div class="additional-add_action">
                                                        <ul>
                                                            <li class="quick-view-btn" data-toggle="modal" data-target="#exampleModalCenter"><a href="javascript:void(0)" data-toggle="tooltip" data-placement="top" title="Quick View"><i
                                                                class="ion-eye"></i></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('single-blog', ['language'=>app()->getLocale(), 'id'=>$blog->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($blog->image, false); ?>" alt="<?php echo e($blog->title, false); ?>">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6><a class="product-name" href="<?php echo e(route('single-blog', ['language'=>app()->getLocale(), 'id'=>$blog->id]), false); ?>"><?php echo e($blog->title, false); ?></a></h6>
                                                    <div class="product-short_desc">
                                                        <p>
                                                            <?php
                                                            if(strlen($blog->body)> 150){
                                                                echo substr($blog->body, 0, 150)."...";
                                                            }else {
                                                                echo $blog->body;
                                                            } 
                                                        ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="add-actions">
                                                    <ul>
                                                        <li><a class="hiraola-add_cart" href="<?php echo e(route('single-blog', ['language'=>app()->getLocale(), 'id'=>$blog->id]), false); ?>" data-toggle="tooltip" data-placement="top" title="Batafsil Information"><?php echo app('translator')->get("More"); ?></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <?php if(count($investments)>0): ?>
                            <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="javascript:void(0)">
                                                    <img class="primary-img" src="/assets/images/i/01.jpg" alt="<?php echo e($invest->title, false); ?>">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h4><a class="product-name" href="javascript:void(0)">“<?php echo e($invest->title, false); ?>"</a></h4>
                                                    
                                                    <div class="product-short_desc">
                                                        
                                                        <b><?php echo app('translator')->get("Address"); ?>: </b><?php echo e($invest->address, false); ?><br>
                                                        <b><?php echo app('translator')->get("Project name"); ?>:</b> <?php echo e($invest->title, false); ?> <br>
                                                        <b><?php echo app('translator')->get("Category"); ?>:</b> <?php echo e($invest->category->name, false); ?><br>
                                                        <b><?php echo app('translator')->get("Avarage power"); ?></b>: <?php echo e($invest->avaragepower, false); ?><br>
                                                        <b><?php echo app('translator')->get("Amount ($ mln)"); ?></b>: <?php echo e($invest->amount, false); ?> <br>
                                                        <b><?php echo app('translator')->get("IRR (fin), for 10 years (%)"); ?></b>: <?php echo e($invest->iir, false); ?> <br>
                                                        <b><?php echo app('translator')->get("NPV (fin), for 10 years (%)"); ?></b>: <?php echo e($invest->npv, false); ?> <br>
                                                        <b><?php echo app('translator')->get("Payback (mounths)"); ?></b>: <?php echo e($invest->payback, false); ?> <br>
                                                        <b><?php echo app('translator')->get("Work places"); ?></b>: <?php echo e($invest->workplaces, false); ?> <br>
                                                        <b><?php echo app('translator')->get("Phone"); ?></b>: +998 71 145 45 02 <br>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>    

                        <?php if(count($buyrequests)>0): ?>
                            <?php $__currentLoopData = $buyrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="slide-item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route("single-request", ['language'=>app()->getLocale(), 'id'=>$buy->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($buy->image, false); ?>" alt="<?php echo e($buy->name, false); ?>">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6 align="center"><a class="product-name" href="<?php echo e(route("single-request", ['language'=>app()->getLocale(), 'id'=>$buy->id]), false); ?>"> <?php echo e($buy->name, false); ?> </a></h6>
                                                    <div class="additional-add_action">
                                                        <ul>
                                                            <li class="quick-view-btn" data-toggle="modal" data-target="#exampleModalCenter"><a href="javascript:void(0)" data-toggle="tooltip" data-placement="top" title="Quick View"><i
                                                                class="ion-eye"></i></a></li>
                                                        </ul>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route("single-request", ['language'=>app()->getLocale(), 'id'=>$buy->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($buy->image, false); ?>" alt="<?php echo e($buy->name, false); ?>">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6><a class="product-name" href="<?php echo e(route("single-request", ['language'=>app()->getLocale(), 'id'=>$buy->id]), false); ?>"> <?php echo e($buy->name, false); ?> </a></h6>
                                                    <div class="rating-box">
                                                        <ul>
                                                            <li><i class="fa fa-star-of-david"></i></li>
                                                            <li><i class="fa fa-star-of-david"></i></li>
                                                            <li><i class="fa fa-star-of-david"></i></li>
                                                            <li><i class="fa fa-star-of-david"></i></li>
                                                            <li class="silver-color"><i class="fa fa-star-of-david"></i></li>
                                                        </ul>
                                                    </div>
                                                    <div class="product-short_desc">
                                                        <p> <?php echo $buy->wants; ?> </p>
                                                    </div>
                                                </div>
                                                <div class="add-actions">
                                                    <ul>
                                                        <li><a class="hiraola-add_cart" href="<?php echo e(route("single-request", ['language'=>app()->getLocale(), 'id'=>$buy->id]), false); ?>" data-toggle="tooltip" data-placement="top" title="Batafsil Information"><?php echo app('translator')->get("More"); ?></a></li>
                                                        
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Hiraola's Content Wrapper Area End Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/search.blade.php ENDPATH**/ ?>