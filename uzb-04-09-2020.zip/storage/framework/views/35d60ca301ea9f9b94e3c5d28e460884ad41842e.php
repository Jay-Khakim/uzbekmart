<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale()), false); ?>" class="no-js">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">


    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="It is the first in Uzbekistan - an online showroom of the Association of Exporters of Uzbekistan.">
    <meta name="author" content="Utkurov_Mahmudjon">
    <meta name="keywords" content="Export , Import , e-commerce , Association , Trade , Tashkent , Online market , showroom , shopping , online store , online business , shopping cart">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title><?php echo e(__("The first online showroom in Uzbekistan"), false); ?> | UzbekMart.com</title>

    <link rel="shortcut icon" type="/image/x-icon" href="/assets/images/logo.png">
    <link rel="stylesheet" href="/assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/vendor/font-awesome.css">
    <link rel="stylesheet" href="/assets/css/vendor/fontawesome-stars.css">
    <link rel="stylesheet" href="/assets/css/vendor/ion-fonts.css">
    <link rel="stylesheet" href="/assets/css/plugins/slick.css">
    <link rel="stylesheet" href="/assets/css/plugins/animate.css">
    <link rel="stylesheet" href="/assets/css/plugins/jquery-ui.min.css">
    <link rel="stylesheet" href="/assets/css/plugins/lightgallery.min.css">
    <link rel="stylesheet" href="/assets/css/plugins/nice-select.css">
    <link rel="stylesheet" href="/assets/css/style.css">
    <?php echo $__env->yieldContent('css'); ?>


    <!-- Scripts -->
    
     
    
    
    

    <!-- Fonts -->
    

    <!-- Styles -->
    
</head>
<body class="template-color-1">
    <div class="main-wrapper">

        

        <header>
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header>

        
        
        
        <?php echo $__env->yieldContent('content'); ?>


        <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    
    <script src="/assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="/assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <script src="/assets/js/vendor/popper.min.js"></script>
    <script src="/assets/js/vendor/bootstrap.min.js"></script>
    <script src="/assets/js/plugins/slick.min.js"></script>
    <script src="/assets/js/plugins/countdown.js"></script>
    <script src="/assets/js/plugins/jquery.barrating.min.js"></script>
    <script src="/assets/js/plugins/jquery.counterup.js"></script>
    <script src="/assets/js/plugins/jquery.nice-select.js"></script>
    <script src="/assets/js/plugins/jquery.sticky-sidebar.js"></script>
    <script src="/assets/js/plugins/jquery-ui.min.js"></script>
    <script src="/assets/js/plugins/jquery.ui.touch-punch.min.js"></script>
    <script src="/assets/js/plugins/lightgallery.min.js"></script>
    
    <script src="/assets/js/plugins/theia-sticky-sidebar.min.js"></script>
    <script src="/assets/js/plugins/waypoints.min.js"></script>
    <script src="/assets/js/plugins/instafeed.min.js"></script>
    <script src="/assets/js/plugins/jquery.elevateZoom-3.0.8.min.js"></script>
    <script src="/assets/js/main.js"></script>
    <?php echo $__env->yieldContent('custom_js'); ?>

    
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/layouts/app.blade.php ENDPATH**/ ?>