data-inline-create-route="<?php echo e($field['inline_create']['create_route'] ?? false, false); ?>"
data-inline-modal-route="<?php echo e($field['inline_create']['modal_route'] ?? false, false); ?>"

data-field-related-name="<?php echo e($field['inline_create']['entity'], false); ?>"
data-inline-create-button="<?php echo e($field['inline_create']['entity'], false); ?>-inline-create-<?php echo e($field['name'], false); ?>"
data-inline-allow-create="<?php echo e(var_export($activeInlineCreate), false); ?>"
data-parent-loaded-fields="<?php echo e(json_encode(array_unique(array_column($crud->fields(),'type'))), false); ?>"
<?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/vendor/backpack/crud/src/resources/views/crud/fields/relationship/field_attributes.blade.php ENDPATH**/ ?>