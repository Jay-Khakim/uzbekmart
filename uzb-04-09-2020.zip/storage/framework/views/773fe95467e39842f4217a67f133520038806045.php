<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('category-show', ['language' => 'uz', 'id' => $cat_id]), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('category-show', ['language' => 'en', 'id' => $cat_id]), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('category-show', ['language' => 'ru', 'id' => $cat_id]), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('category-show', ['language' => 'uz', 'id' => $cat_id]), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('category-show', ['language' => 'en', 'id' => $cat_id]), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    <a href="<?php echo e(route('category-show', ['language' => 'ru', 'id' => $cat_id]), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2># 
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cat->id == $cat_id): ?>
                            <?php echo e($cat->name, false); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </h2>
                
            </div>
        </div>
    </div>



<div class="hiraola-content_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="shop-toolbar">
                            <div class="product-view-mode">
                                <a class=" grid-3" data-target="gridview-3" data-toggle="tooltip" data-placement="top" title="Grid View"><i class="fa fa-th"></i></a>
                                
                            </div>
                            <span><?php echo app('translator')->get('Totally'); ?>: 
                                <?php echo e(count($one_categories), false); ?>

                                <?php if(count($one_categories)>1): ?>
                                    <?php echo app('translator')->get('companies'); ?>
                                <?php else: ?> 
                                    <?php echo app('translator')->get('company'); ?>
                                <?php endif; ?>

                            </span>
                            
                        </div>
                        <div class="shop-product-wrap grid gridview-5 row">

                            
                            <?php $__currentLoopData = $one_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="slide-item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$one->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($one->image, false); ?>" alt="<?php echo e($one->name, false); ?>">
                                                </a>

                                                <span class="sticker-2">New</span>
                                            </div>
                                            <br>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h5><span class="badge  badge-primary"> #<?php echo e($one->category->name, false); ?> </span></h5>
                                                    <h6 align="center"><a class="product-name" href="<?php echo e(route('comp-show', [app()->getLocale(), $one->id]), false); ?>"> <?php echo e($one->name, false); ?> </a></h6>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route('comp-show', [app()->getLocale(), $one->id]), false); ?>">
                                                    <img class="primary-img" src=" <?php echo e($one->image, false); ?>" alt="<?php echo e($one->name, false); ?> ">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6><a class="product-name" href="<?php echo e(route('comp-show', [app()->getLocale(), $one->id]), false); ?>"> <?php echo e($one->name, false); ?> </a></h6>
                                                    
                                                    <div class="product-short_desc">
                                                        <p><?php echo e($one->desc, false); ?></p>
                                                    </div>
                                                </div>
                                                <div class="add-actions">
                                                    <ul>
                                                        <li><a class="hiraola-add_cart" href="<?php echo e(route('comp-show', [app()->getLocale(), $one->id]), false); ?>" data-toggle="tooltip" data-placement="top" title="More info"><?php echo app('translator')->get("More"); ?></a></li>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            

                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/companies/categ-show.blade.php ENDPATH**/ ?>