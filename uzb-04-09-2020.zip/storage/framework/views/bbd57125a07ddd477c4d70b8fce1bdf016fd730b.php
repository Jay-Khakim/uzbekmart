

<li filter-name="<?php echo e($filter->name, false); ?>"
	filter-type="<?php echo e($filter->type, false); ?>"
	class="nav-item dropdown <?php echo e(Request::get($filter->name)?'active':'', false); ?>">
	<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e($filter->label, false); ?> <span class="caret"></span></a>
	<div class="dropdown-menu p-0">
		<div class="form-group backpack-filter mb-0">
			<div class="input-group date">
		        <div class="input-group-prepend">
		          <span class="input-group-text"><i class="la la-calendar"></i></span>
		        </div>
		        <input class="form-control pull-right"
		        		id="datepicker-<?php echo e($filter->name, false); ?>"
		        		type="text"
						<?php if($filter->currentValue): ?>
							value="<?php echo e($filter->currentValue, false); ?>"
						<?php endif; ?>
		        		>
		        <div class="input-group-append datepicker-<?php echo e($filter->name, false); ?>-clear-button">
		          <a class="input-group-text" href=""><i class="la la-times"></i></a>
		        </div>
		    </div>
		</div>
	</div>
</li>







<?php $__env->startPush('crud_list_styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('packages/bootstrap-datepicker/dist/css/bootstrap-datepicker3.css'), false); ?>">
	<style>
		.input-group.date {
			width: 320px;
			max-width: 100%;
		}
	</style>
<?php $__env->stopPush(); ?>





<?php $__env->startPush('crud_list_scripts'); ?>
	<!-- include select2 js-->
	<script src="<?php echo e(asset('packages/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js'), false); ?>"></script>
  <script>
		jQuery(document).ready(function($) {
			var dateInput = $('#datepicker-<?php echo e($filter->name, false); ?>').datepicker({
				autoclose: true,
				format: 'yyyy-mm-dd',
				todayHighlight: true
			})
			.on('changeDate', function(e) {
				var d = new Date(e.date);
				// console.log(e);
				// console.log(d);
				if (isNaN(d.getFullYear())) {
					var value = '';
				} else {
					var value = d.getFullYear() + "-" + ("0"+(d.getMonth()+1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
				}

				// console.log(value);

				var parameter = '<?php echo e($filter->name, false); ?>';

		    	// behaviour for ajax table
				var ajax_table = $('#crudTable').DataTable();
				var current_url = ajax_table.ajax.url();
				var new_url = addOrUpdateUriParameter(current_url, parameter, value);

				// replace the datatables ajax url with new_url and reload it
				new_url = normalizeAmpersand(new_url.toString());
				ajax_table.ajax.url(new_url).load();

				// add filter to URL
				crud.updateUrl(new_url);

				// mark this filter as active in the navbar-filters
				if (URI(new_url).hasQuery('<?php echo e($filter->name, false); ?>', true)) {
					$('li[filter-name=<?php echo e($filter->name, false); ?>]').removeClass('active').addClass('active');
				}
			});

			$('li[filter-name=<?php echo e($filter->name, false); ?>]').on('filter:clear', function(e) {
				// console.log('date filter cleared');
				$('li[filter-name=<?php echo e($filter->name, false); ?>]').removeClass('active');
				$('#datepicker-<?php echo e($filter->name, false); ?>').datepicker('update', '');
				$('#datepicker-<?php echo e($filter->name, false); ?>').trigger('changeDate');
			});

			// datepicker clear button
			$(".datepicker-<?php echo e($filter->name, false); ?>-clear-button").click(function(e) {
				e.preventDefault();

				$('li[filter-name=<?php echo e($filter->name, false); ?>]').trigger('filter:clear');
			})
		});
  </script>
<?php $__env->stopPush(); ?>


<?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/vendor/backpack/crud/src/resources/views/crud/filters/date.blade.php ENDPATH**/ ?>