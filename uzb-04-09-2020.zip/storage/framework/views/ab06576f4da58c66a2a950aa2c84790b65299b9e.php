<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('faq', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('faq', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('faq', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('faq', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('faq', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    <a href="<?php echo e(route('faq', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <!-- Begin Hiraola's Breadcrumb Area -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2><?php echo app('translator')->get("FAQ"); ?></h2>
                <ul>
                    <li><a href="<?php echo e(route('main' ,app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li class="active"><?php echo app('translator')->get("Frequently asked questions"); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Hiraola's Breadcrumb Area End Here -->


    <!-- Begin Hiraola's Frequently Area -->
    <div class="frequently-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="frequently-content">
                        <div class="frequently-desc">
                            <h3><strong><?php echo app('translator')->get("What security measures does UzbekMART take?  "); ?></strong></h3>
                            <p><?php echo app('translator')->get("UzbekMART gives high amount of importance to the Personal Information Security of its customers."); ?><br>
                                -<?php echo app('translator')->get("UzbekMART is committed to the security of its buyers and suppliers. Security is the core element for our healthy growth, and to achieve this we use 256-bit encryption technology"); ?><br>
                                <?php echo app('translator')->get("-All your online transactions on UzbekMART are secure with the highest levels of transaction security currently available on the Internet."); ?><br>
                                <?php echo app('translator')->get("-Apart from this, all your information is safe with us as we do not share this with any third party for commercial use"); ?>.<br>
                            </p>
                        </div>
                    </div>
                    <!-- Begin Frequently Accordin -->
                    <div class="frequently-accordion">
                        <div id="accordion">
                            <div class="card actives">
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                        <a href="javascript:void(0)" class="" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            <?php echo app('translator')->get("How do I search for a product / service on UzbekMART?"); ?>
                                        </a>
                                    </h5>
                                </div>
                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                    <div class="card-body">
                                        <?php echo app('translator')->get("You can search for a Product or Service on UzbekMART using the steps mentioned below"); ?>:<br>
                                        - <?php echo app('translator')->get("Visit www.uzbekmart.com and search for the product/company name using search box"); ?>; <br>
                                        -<?php echo app('translator')->get("From the search result page, you can also choose/enter the preferred city of product/supplier you wish to source products"); ?>.
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingTwo">
                                    <h5 class="mb-0">
                                        <a href="javascript:void(0)" class="collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            <?php echo app('translator')->get("How does a buyer provide feedback/rating to a seller listed on UzbekMART?"); ?>
                                        </a>
                                    </h5>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                    <div class="card-body">
                                        <?php echo app('translator')->get("A buyer can provide his feedback to UzbekMART through responding on the feedback emails. Buyers can share seller feedback as well as their feedback about overall UzbekMART experience through these emails, by clicking on the corresponding mode of completion. "); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingThree">
                                    <h5 class="mb-0">
                                        <a href="javascript:void(0)" class="collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                           <?php echo app('translator')->get("What is Star Supplier package?"); ?>
                                        </a>
                                    </h5>
                                </div>
                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                    <div class="card-body">
                                        <?php echo app('translator')->get("Star service is a premium listing service by UzbekMART which gives you priority listing in your chosen category-city combinations. With this service, experience increased leads, enquiries and the opportunity to get more business."); ?>
                                    </div>
                                </div>
                            </div>
                            
                            
                            <div class="card">
                                <div class="card-header" id="headingSix">
                                    <h5 class="mb-0">
                                        <a href="javascript:void(0)" class="collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                            <?php echo app('translator')->get("How do I activate my account? "); ?>
                                        </a>
                                    </h5>
                                </div>
                                <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordion">
                                    <div class="card-body">
                                        <?php echo app('translator')->get("The instructions to activate your account will be sent to your email once you have submitted the registration form. If you did not receive this email, your email service provider’s mailing software may be blocking it. You can try checking your junk / spam folder or contact us at info@uzbekmart.com "); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingSeven">
                                    <h5 class="mb-0">
                                        <a href="javascript:void(0)" class="collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                            <?php echo app('translator')->get("What are the payment methods available?"); ?>
                                        </a>
                                    </h5>
                                </div>
                                <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordion">
                                    <div class="card-body">
                                        <?php echo app('translator')->get("At the moment, we only accept Uzcards, Humo and Paypal payments."); ?>                                        
                                    </div>
                                </div>
                            </div>
    
                        </div>
                    </div>
                    <!--Frequently Accordin End Here -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/faq.blade.php ENDPATH**/ ?>