<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(url( 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(url('en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(url('ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(url('uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(url('en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    <a href="<?php echo e(url('ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="slider-with-category_menu">
        <div class="container-fluid">
            <div class="row">
                <div id="slider01" class="col grid-half order-md-2 order-lg-1">
                    <div class="category-menu">
                        <div class="category-heading">
                            
                            <h2 class="categories-toggle"><span><?php echo app('translator')->get('Categories'); ?></span></h2>
                        </div>
                        <div id="cate-toggle" class="category-menu-list">
                            <ul>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="right-menu"><a href="<?php echo e(route('category-show', ['language'=>app()->getLocale(), 'id'=>$cat->id]), false); ?>"><img class="img-fluid"  src="/storage/<?php echo e($cat->image, false); ?>" alt="" class="mr-3"><span class="ml-1"><?php echo e($cat->name, false); ?> </span></a>
                                        
                                        
                                        
                                        
                                        
                                            
                                        <ul class="cat-mega-menu cat-mega-menu-3">
                                            <?php $__currentLoopData = $subcategories->where('category_id', $cat->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                    <div id="div_top_hypers">
                                                        <ul id="ul_top_hypers">
                                                            <li>/ <a href="<?php echo e(route('subcategory-show', ['language'=>app()->getLocale(), 'cid'=>$cat->id, 'sid'=> $sub->id]), false); ?>" class="a_top_hypers"> <?php echo e($sub->name, false); ?> </a></li> 
                                                        </ul>
                                                    </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>   
                                        
                                        
                                    </li>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                    <div class="col grid-full order-md-1 order-lg-2">
                    <div class="hiraola-slider_area">
                        <div class="main-slider">
                            <!-- Begin Single Slide Area -->
                            <div class="single-slide animation-style-01 bg-1">
                                <div class="container">
                                    <div class="slider-content">
                                        <!-- <h5>Янги платформа</h5> -->
                                        <h2><?php echo e(__("The first online showroom"), false); ?> </h2>
                                        <h3><?php echo e(__("onlayn shourum "), false); ?></h3>
                                        <h4><?php echo e(__("If you want to become one of us, please contact with us"), false); ?></h4>
                                        <div class="hiraola-btn-ps_right slide-btn ">
                                            <a class="hiraola-btn" href="contact.html"><?php echo e(__("Contact now"), false); ?></a>
                                        </div>
                                    </div>
                                    <div class="slider-progress"></div>
                                </div>
                            </div>
                            <!-- Single Slide Area End Here -->
                            <!-- Begin Single Slide Area -->
                            <div class="single-slide animation-style-02 bg-2">
                                <div class="container">

                                    <div class="slider-progress"></div>
                                </div>
                            </div>
                            <div class="single-slide animation-style-02 bg-3">
                                <div class="container">

                                    <div class="slider-progress"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="slider02" class="row">
                    <div class="category_company col-12 d-md-none my-4">
                        
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="category_item px-2">
                                <a href="<?php echo e(route('category-show', ['language'=>app()->getLocale(), 'id'=>$cat->id]), false); ?>" class="item_link">
                                    <div class="mx-auto">
                                        <img src="/storage/<?php echo e($cat->image, false); ?>" alt="">
                                    </div>
                                    <div class="category_title mx-auto">
                                        <span> <?php echo e($cat->name_en, false); ?> </span>
                                    </div>
                                </a>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div id="banner1" class="col grid-half grid-md_half order-md-2 order-lg-3">
                    <div class="banner-item img-hover_effect">
                        <a href="http://exportuz.com/">
                            <img class="img-full" src="assets/images/banner/1_1.jpg" alt="Hiraola's Banner">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
                
    




    
    <div class="hiraola-product_area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hiraola-section_title">
                        <h4><?php echo e(__("Local companies"), false); ?></h4>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="hiraola-product_slider">
                        <!-- Begin Hiraola's Slide Item Area -->
                        <?php $__currentLoopData = $localcomp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slide-item">
                                <div class="single_product">
                                    <div class="product-img">
                                        <a href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$local->id]), false); ?>">
                                            <img class="primary-img" src="/storage/<?php echo e($local->image, false); ?> " alt=" <?php echo e($local->name, false); ?> ">
                                        </a>
                                        <span class="sticker-2">New</span>
                                    </div>
                                    <div class="hiraola-product_content">
                                        <div class="product-desc_info">
                                            <h5><span class="badge badge-primary"> #<?php echo e($local->category->name, false); ?> </span></h5>
                                            <h6 align="center">
                                                <a class="product-name" href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$local->id]), false); ?>">
                                                    <?php
                                                    if(strlen($local->name)> 15){
                                                        echo substr($local->name, 0, 15)."...";
                                                    }else {
                                                        echo $local->name;
                                                    }  
                                                    ?>   
                                                </a>
                                            </h6>
                                        </div>
                                    </div>
                                </div>   
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
            </div> <br>
                <div  class="hiraola-btn-ps_center  text-center" id="btn21">
                        <a class="hiraola-btn" href="<?php echo e(route('local-comp' ,app()->getLocale()), false); ?>"><?php echo e(__("More"), false); ?></a>
                </div>
        </div>
    </div>
    

    
    <!-- Begin Hiraola's Product Area -->
    <div class="hiraola-product_area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hiraola-section_title">
                        <h4><?php echo e(__("Foreign companies"), false); ?></h4>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="hiraola-product_slider">
                        <!-- Begin Hiraola's Slide Item Area -->
                        <?php $__currentLoopData = $foreigncomp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foreign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="slide-item">
                                <div class="single_product">
                                    <div class="product-img">
                                        <a href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$foreign->id]), false); ?>">
                                            <img class="primary-img" src="/storage/<?php echo e($foreign->image, false); ?> " alt=" <?php echo e($foreign->name, false); ?> ">
                                        </a>
                                        <span class="sticker-2">New</span>
                                    </div>
                                    <div class="hiraola-product_content">
                                        <div class="product-desc_info">
                                            <h5><span class="badge  badge-primary">#<?php echo e($foreign->category->name, false); ?></span></h5>
                                            <h6 align="center">
                                                <a class="product-name" href="<?php echo e(route('comp-show', ['language'=>app()->getLocale(), 'id'=>$foreign->id]), false); ?>">
                                                    
                                                    <?php
                                                    if(strlen($foreign->name)> 15){
                                                        echo substr($foreign->name, 0, 15)."...";
                                                    }else {
                                                        echo $foreign->name;
                                                    }  
                                                    ?>   
                                                </a>
                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </div>
                </div>
            </div><br>
                <div  class="hiraola-btn-ps_center  text-center" id="btn21">
                        <a class="hiraola-btn" href="<?php echo e(route('foreign-comp' ,app()->getLocale()), false); ?>"><?php echo e(__("More"), false); ?></a>
                </div>
        </div>
    </div><br><br>
    <!-- Hiraola's Product Area End Here -->
    

    
    <div class="container">
        <div class="row" id="banner11">
            <div class="col-lg-12" align="center">
                <div class="slider-content">
                <h3><?php echo e(__("Register your company in the first online showroom in Uzbekistan and improve your business"), false); ?> </h3>
                    <div  class="hiraola-btn-ps_center  text-center pt-4"  id="btn21">
                        <a class="hiraola-btn" 
                            <?php if(app()->getLocale() === 'en'): ?>
                                href="https://docs.google.com/forms/d/e/1FAIpQLSc7sTFRqxgyR_1MKlXPxHzOndlaBgLPYqt8iWWzzQaYmgmHgQ/viewform"
                            <?php else: ?>
                                href="https://docs.google.com/forms/d/e/1FAIpQLSd_RjwstS1_qq6QK32SxJ7ZCJzwj2jFSUD6CIGmiEvzDc5_5w/viewform?usp=sf_link"
                            <?php endif; ?>>
                            <?php echo e(__("Register"), false); ?></a>
                            
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    
    <?php echo $__env->make('inc.statistics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
    
    
    <?php echo $__env->make('inc.partners', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    
    <div class="hiraola-shipping_area">
        <div class="container">
            <div class="shipping-nav">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="shipping-item">
                            <div class="shipping-icon">
                                <img src="/assets/images/shipping-icon/1.png" alt="Hiraola's Shipping Icon">
                            </div>
                            <div class="shipping-content">
                                <h6><?php echo e(__("Under Uzbekistan Export Association"), false); ?></h6>
                                <p><?php echo e(__("Everything is controlled"), false); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="shipping-item">
                            <div class="shipping-icon">
                                <img src="/assets/images/shipping-icon/2.png" alt="Hiraola's Shipping Icon">
                            </div>
                            <div class="shipping-content">
                                <h6><?php echo e(__("Available Paymet methods"), false); ?></h6>
                                <p>Uzcard, Humo, Master/Visa card</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="shipping-item">
                            <div class="shipping-icon">
                                <img src="assets/images/shipping-icon/3.png" alt="Hiraola's Shipping Icon">
                            </div>
                            <div class="shipping-content">
                                <h6>100% <?php echo e(__("Confidential"), false); ?></h6>
                                <p><?php echo e(__("Secured by Association"), false); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="shipping-item">
                            <div class="shipping-icon">
                                <img src="/assets/images/shipping-icon/4.png" alt="Hiraola's Shipping Icon">
                            </div>
                            <div class="shipping-content">
                                <h6><?php echo e(__("Experienced"), false); ?></h6>
                                <p><?php echo e(__("2 years experience"), false); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Hiraola's Shipping Area End Here -->
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/index.blade.php ENDPATH**/ ?>