<!-- This file is used to store topbar (left) items -->


<?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/vendor/backpack/crud/src/resources/views/base/inc/topbar_left_content.blade.php ENDPATH**/ ?>