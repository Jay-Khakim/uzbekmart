<!-- select2 -->
<?php
    $current_value = old($field['name']) ? old($field['name']) : (isset($field['value']) ? $field['value'] : (isset($field['default']) ? $field['default'] : '' ));
?>

<?php echo $__env->make('crud::fields.inc.wrapper_start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <label><?php echo $field['label']; ?></label>
    <?php echo $__env->make('crud::fields.inc.translatable_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php
        $entity_model = $crud->model;
        $related_model = $crud->getRelationModel($field['entity']);
        $group_by_model = (new $related_model)->{$field['group_by']}()->getRelated();
        $categories = $group_by_model::with($field['group_by_relationship_back'])->get();
        
        if (isset($field['model'])) {
            $categorylessEntries = $related_model::doesnthave($field['group_by'])->get();
        }
    ?>
    <select
        name="<?php echo e($field['name'], false); ?>"
        style="width: 100%"
        <?php echo $__env->make('crud::fields.inc.attributes', ['default_class' =>  'form-control'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        >

            <?php if($entity_model::isColumnNullable($field['name'])): ?>
                <option value="">-</option>
            <?php endif; ?>

            <?php if(isset($field['model']) && isset($field['group_by'])): ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <optgroup label="<?php echo e($category->{$field['group_by_attribute']}, false); ?>">
                        <?php $__currentLoopData = $category->{$field['group_by_relationship_back']}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subEntry->getKey(), false); ?>"
                                <?php if( ( old($field['name']) && old($field['name']) == $subEntry->getKey() ) || (isset($field['value']) && $subEntry->getKey()==$field['value'])): ?>
                                     selected
                                <?php endif; ?>
                            ><?php echo e($subEntry->{$field['attribute']}, false); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($categorylessEntries->count()): ?>
                    <optgroup label="-">
                        <?php $__currentLoopData = $categorylessEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($current_value == $subEntry->getKey()): ?>
                                <option value="<?php echo e($subEntry->getKey(), false); ?>" selected><?php echo e($subEntry->{$field['attribute']}, false); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($subEntry->getKey(), false); ?>"><?php echo e($subEntry->{$field['attribute']}, false); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                <?php endif; ?>
            <?php endif; ?>
    </select>

    
    <?php if(isset($field['hint'])): ?>
        <p class="help-block"><?php echo $field['hint']; ?></p>
    <?php endif; ?>
<?php echo $__env->make('crud::fields.inc.wrapper_end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/vendor/backpack/crud/src/resources/views/crud/fields/select_grouped.blade.php ENDPATH**/ ?>