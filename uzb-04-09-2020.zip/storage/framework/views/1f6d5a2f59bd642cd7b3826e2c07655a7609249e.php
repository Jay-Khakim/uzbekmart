<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('buy-request', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    </li>
    <li>
        <a href="<?php echo e(route('buy-request', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    </li>
    <li>
        <a href="<?php echo e(route('buy-request', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lang-mobile'); ?>
    <a href="<?php echo e(route('buy-request', 'uz'), false); ?>"><img src="/assets/images/menu/icon/3.jpg" alt="JB's Language Icon">Uz</a>
    <a href="<?php echo e(route('buy-request', 'en'), false); ?>"><img src="/assets/images/menu/icon/1.jpg" alt="JB's Language Icon">En</a>
    <a href="<?php echo e(route('buy-request', 'ru'), false); ?>"><img src="/assets/images/menu/icon/2.jpg" alt="JB's Language Icon">Ru</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <!-- Begin Hiraola's Breadcrumb Area -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="breadcrumb-content">
                <h2><?php echo app('translator')->get("Buy or Request"); ?></h2>
                <ul>
                    <li><a href="<?php echo e(route("main", app()->getLocale()), false); ?>"><?php echo app('translator')->get("Home"); ?></a></li>
                    <li class="active"><?php echo app('translator')->get("Services"); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Hiraola's Breadcrumb Area End Here -->

    <!-- Begin Hiraola's Content Wrapper Area -->
        <div class="hiraola-content_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 order-2 order-lg-2">
                        <div class="hiraola-sidebar-catagories_area">
                            <div id="btn25" class="">
                                <a href="https://docs.google.com/forms/d/e/1FAIpQLSfNDOUnLsMH1jT_rATjzuc4XfwmQrN2pwuTebSm6YKCjwVnZw/viewform?usp=sf_link" id="btn25" class="btn btn-primary"><h5 style="color: white;"><?php echo app('translator')->get("Request"); ?></h5></a>
                            </div>
                            <div class="category-module hiraola-sidebar_categories">
                                <div class="category-module_heading">
                                    <h5><?php echo app('translator')->get("Categories"); ?></h5>
                                </div>
                                <div class="module-body">
                                    <ul class="module-list_item">
                                        <li>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="javascript:void(0)"><?php echo e($category->name, false); ?> <?php $__currentLoopData = $buyrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $a = 0;
                                                        if ($buy->category_id === $category->id) {
                                                            $a = $a+1;
                                                        }
                                                        echo " (".$a.")";
                                                    ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="sidebar-banner_area">
                            <div class="banner-item img-hover_effect">
                                <a href="javascript:void(0)">
                                    <img src="assets/images/banner/1_1.jpg" alt="Hiraola's Shop Banner Image">
                                </a>
                            </div>
                        </div> -->
                    </div>
                    <div class="col-lg-9 order-1 order-lg-1">
                        <div class="shop-toolbar">
                            <div class="product-view-mode">
                                
                                <a class="active list" data-target="listview" data-toggle="tooltip" data-placement="top" title="List View"><i class="fa fa-th-list"></i></a>
                            </div>
                            <span><?php echo app('translator')->get('Totally'); ?>: 
                                <?php echo e(count($buyrequests), false); ?>

                                <?php if(count($buyrequests)>1): ?>
                                    <?php echo app('translator')->get('buy/requests'); ?>
                                <?php else: ?> 
                                    <?php echo app('translator')->get('buy/request'); ?>
                                <?php endif; ?>

                            </span>
                            
                        </div>
                        <div class="shop-product-wrap grid listview row">
                            <?php $__currentLoopData = $buyrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="slide-item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route("single-request", ['language'=>app()->getLocale(), 'id'=>$buy->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($buy->image, false); ?>" alt="<?php echo e($buy->name, false); ?>">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6 align="center"><a class="product-name" href="<?php echo e(route("single-request", ['language'=>app()->getLocale(), 'id'=>$buy->id]), false); ?>"> <?php echo e($buy->name, false); ?> </a></h6>
                                                    <div class="additional-add_action">
                                                        <ul>
                                                            <li class="quick-view-btn" data-toggle="modal" data-target="#exampleModalCenter"><a href="javascript:void(0)" data-toggle="tooltip" data-placement="top" title="Quick View"><i
                                                                class="ion-eye"></i></a></li>
                                                        </ul>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list-slide_item">
                                        <div class="single_product">
                                            <div class="product-img">
                                                <a href="<?php echo e(route("single-request", ['language'=>app()->getLocale(), 'id'=>$buy->id]), false); ?>">
                                                    <img class="primary-img" src="/storage/<?php echo e($buy->image, false); ?>" alt="<?php echo e($buy->name, false); ?>">
                                                </a>
                                            </div>
                                            <div class="hiraola-product_content">
                                                <div class="product-desc_info">
                                                    <h6><a class="product-name" href="<?php echo e(route("single-request", ['language'=>app()->getLocale(), 'id'=>$buy->id]), false); ?>"> <?php echo e($buy->name, false); ?> </a></h6>
                                                    <div class="rating-box">
                                                        <ul>
                                                            <li><i class="fa fa-star-of-david"></i></li>
                                                            <li><i class="fa fa-star-of-david"></i></li>
                                                            <li><i class="fa fa-star-of-david"></i></li>
                                                            <li><i class="fa fa-star-of-david"></i></li>
                                                            <li class="silver-color"><i class="fa fa-star-of-david"></i></li>
                                                        </ul>
                                                    </div>
                                                    <div class="product-short_desc">
                                                        <p> <?php echo $buy->wants; ?> </p>
                                                    </div>
                                                </div>
                                                <div class="add-actions">
                                                    <ul>
                                                        <li><a class="hiraola-add_cart" href="<?php echo e(route("single-request", ['language'=>app()->getLocale(), 'id'=>$buy->id]), false); ?>" data-toggle="tooltip" data-placement="top" title="Batafsil Information"><?php echo app('translator')->get("More"); ?></a></li>
                                                        
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hiraola's Content Wrapper Area End Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/myfolder/uzbekmart-l/resources/views/buy-request/buy-request.blade.php ENDPATH**/ ?>